import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import subprocess
import asyncio
from typing import Dict, Any
from core.base import Tool

class OpenChromeTool(Tool):
    '''打开 Chrome 浏览器的工具'''
    
    @property
    def name(self) -> str:
        return "open_chrome"
    
    @property
    def description(self) -> str:
        return "在 Linux 系统上打开 Chrome 浏览器，支持指定 URL"
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "要打开的 URL 地址（可选）"
                }
            },
            "required": []
        }
    
    async def execute(self, **kwargs) -> str:
        '''执行工具'''
        url = kwargs.get('url', '')
        
        # 构建 Chrome 命令
        chrome_cmd = ['google-chrome']
        
        # 如果指定了 URL，则添加到命令中
        if url:
            chrome_cmd.append(url)
        
        # 添加后台运行参数
        chrome_cmd.extend(['--new-window'])
        
        try:
            # 使用 subprocess.Popen 后台运行，不阻塞
            process = subprocess.Popen(
                chrome_cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True
            )
            
            if url:
                return f"Chrome 浏览器已启动，正在打开: {url}"
            else:
                return "Chrome 浏览器已启动"
                
        except FileNotFoundError:
            return "错误: 未找到 Chrome 浏览器，请确保已安装 Google Chrome"
        except Exception as e:
            return f"启动 Chrome 浏览器时出错: {str(e)}"
