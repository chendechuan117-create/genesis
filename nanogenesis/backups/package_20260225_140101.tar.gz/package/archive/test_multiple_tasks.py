#!/usr/bin/env python3
"""
测试 Genesis 处理多个真实任务
"""

import asyncio
import os
from simple_auto_tool_demo import ToolGenerator
from core.registry import ToolRegistry
from tools.file_tools import ReadFileTool, WriteFileTool, ListDirectoryTool
from tools.shell_tool import ShellTool


async def test_task(task_name: str, task_description: str, tool_name: str, tool_args: dict, registry: ToolRegistry, generator: ToolGenerator):
    """测试单个任务"""
    print(f"\n{'='*60}")
    print(f"任务: {task_name}")
    print(f"{'='*60}")
    print(f"描述: {task_description}")
    
    # 检查工具是否存在
    if tool_name not in registry:
        print(f"\n🔧 工具 '{tool_name}' 不存在，自动生成...")
        
        # 生成工具
        tool_file = generator.generate_tool(task_description, tool_name)
        
        if tool_file:
            try:
                tool = generator.load_tool(tool_file)
                registry.register(tool)
                print(f"   ✓ 工具已生成并注册")
            except Exception as e:
                print(f"   ✗ 工具加载失败: {e}")
                return False
        else:
            print(f"   ✗ 工具生成失败")
            return False
    else:
        print(f"\n✓ 工具 '{tool_name}' 已存在")
    
    # 执行工具
    print(f"\n执行工具...")
    try:
        result = await registry.execute(tool_name, tool_args)
        print(f"✓ 执行成功")
        print(f"结果: {result[:200] if len(result) > 200 else result}")
        return True
    except Exception as e:
        print(f"✗ 执行失败: {e}")
        return False


async def main():
    print("="*60)
    print("Genesis 多任务测试")
    print("="*60)
    
    api_key = os.getenv('DEEPSEEK_API_KEY')
    if not api_key:
        raise RuntimeError("请先设置环境变量 DEEPSEEK_API_KEY")
    generator = ToolGenerator(api_key=api_key)
    registry = ToolRegistry()
    
    # 注册基础工具
    registry.register(ReadFileTool())
    registry.register(WriteFileTool())
    registry.register(ListDirectoryTool())
    registry.register(ShellTool())
    
    print(f"\n初始工具数: {len(registry)}")
    print(f"可用工具: {registry.list_tools()}")
    
    # 定义测试任务
    tasks = [
        {
            "name": "任务1: 列出当前目录文件",
            "description": "列出指定目录中的所有文件和子目录",
            "tool": "list_directory",
            "args": {"path": "."}
        },
        {
            "name": "任务2: 查看系统信息",
            "description": "获取系统的基本信息（操作系统、CPU、内存等）",
            "tool": "get_system_info",
            "args": {}
        },
        {
            "name": "任务3: 创建测试文件",
            "description": "在指定路径创建一个测试文件",
            "tool": "write_file",
            "args": {
                "path": "/tmp/genesis_test.txt",
                "content": "Genesis 测试文件\n这是由 Genesis 自动创建的。"
            }
        },
        {
            "name": "任务4: 读取刚创建的文件",
            "description": "读取指定文件的内容",
            "tool": "read_file",
            "args": {"path": "/tmp/genesis_test.txt"}
        },
        {
            "name": "任务5: 获取当前时间",
            "description": """
            创建一个获取当前系统时间的工具。
            
            功能：
            - 获取当前日期和时间
            - 格式化输出（YYYY-MM-DD HH:MM:SS）
            - 包含时区信息
            """,
            "tool": "get_current_time",
            "args": {}
        }
    ]
    
    # 执行所有任务
    results = []
    for task in tasks:
        success = await test_task(
            task["name"],
            task["description"],
            task["tool"],
            task["args"],
            registry,
            generator
        )
        results.append((task["name"], success))
        await asyncio.sleep(0.5)  # 避免 API 限流
    
    # 总结
    print(f"\n{'='*60}")
    print("测试总结")
    print(f"{'='*60}")
    
    success_count = sum(1 for _, success in results if success)
    total_count = len(results)
    
    print(f"\n总任务数: {total_count}")
    print(f"成功: {success_count}")
    print(f"失败: {total_count - success_count}")
    print(f"成功率: {success_count/total_count*100:.1f}%")
    
    print(f"\n最终工具数: {len(registry)}")
    print(f"自动生成的工具: {len(registry) - 4}")  # 减去初始的4个工具
    
    print("\n任务详情:")
    for name, success in results:
        status = "✓" if success else "✗"
        print(f"  {status} {name}")
    
    if success_count == total_count:
        print("\n🎉 所有任务完成！Genesis 工作正常！")
    else:
        print(f"\n⚠️ 有 {total_count - success_count} 个任务失败")


if __name__ == '__main__':
    asyncio.run(main())
