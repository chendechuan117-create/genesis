import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.base import Tool
from typing import Dict, Any
from datetime import datetime
import pytz

class GetCurrentTimeTool(Tool):
    '''获取当前系统时间工具'''
    
    @property
    def name(self) -> str:
        return "get_current_time"
    
    @property
    def description(self) -> str:
        return "获取当前系统时间，包含日期、时间和时区信息，格式为YYYY-MM-DD HH:MM:SS"
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "timezone": {
                    "type": "string",
                    "description": "时区名称，如'Asia/Shanghai'、'America/New_York'，默认为系统时区"
                }
            },
            "required": []
        }
    
    async def execute(self, **kwargs) -> str:
        '''执行工具'''
        timezone_str = kwargs.get('timezone')
        
        if timezone_str:
            try:
                tz = pytz.timezone(timezone_str)
                current_time = datetime.now(tz)
            except pytz.exceptions.UnknownTimeZoneError:
                return f"错误：未知时区 '{timezone_str}'"
        else:
            current_time = datetime.now()
        
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        
        if current_time.tzinfo:
            timezone_info = current_time.strftime("%Z")
            offset = current_time.strftime("%z")
            return f"{formatted_time} {timezone_info} (UTC{offset})"
        else:
            return f"{formatted_time} (系统本地时间)"
