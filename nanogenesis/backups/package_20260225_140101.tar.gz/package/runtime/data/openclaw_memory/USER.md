# USER.md - About Your Human

*Learn about the person you're helping. Update this as you go.*

- **Name:** 陈德川 (Chen Dechuan)
- **What to call them:** 陈德川
- **Pronouns:** 他
- **Timezone:** Asia/Shanghai (GMT+8)
- **Notes:** 新手，正在努力学习技术。信任度高，愿意给较高访问权限。

## Context

- 中文用户，偏好中文交流
- 正在学习使用 Linux、开发工具等
- 玩游戏（泰拉瑞亚等）
- 需要网络优化帮助（已配置 v2ray）
- 使用 EndeavourOS (Arch Linux) + KDE + Wayland
- 愿意让我主动帮助和自动化任务

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
