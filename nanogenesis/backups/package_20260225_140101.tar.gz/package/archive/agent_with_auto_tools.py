#!/usr/bin/env python3
"""
Genesis Agent - 带自动工具生成（类似 OpenClaw）

当 Agent 需要一个不存在的工具时，自动生成并注册
"""

import asyncio
import os
from typing import Dict, Optional
from agent_with_polyhedron import NanoGenesisWithPolyhedron
from intelligence.tool_generator import ToolGenerator


class GenesisWithAutoTools(NanoGenesisWithPolyhedron):
    """带自动工具生成的 Genesis Agent"""
    
    def __init__(self, api_key: str, **kwargs):
        super().__init__(api_key=api_key, **kwargs)
        self.tool_generator = ToolGenerator(api_key=api_key)
        self.auto_generated_tools = []
    
    async def process_with_auto_tools(
        self,
        user_input: str,
        **kwargs
    ) -> Dict:
        """
        处理请求，自动生成缺失的工具
        
        工作流：
        1. 尝试正常处理
        2. 如果失败且提示缺少工具，自动生成
        3. 重新处理
        """
        
        # 第一次尝试
        result = await self.process(user_input, **kwargs)
        
        # 检查是否需要生成工具
        response = result['response']
        
        # 简单检测：如果响应中提到"没有"、"无法"等，可能需要新工具
        need_tool = any(keyword in response for keyword in [
            '没有', '无法', '不支持', '缺少', '不存在'
        ])
        
        if need_tool and '工具' in response:
            logger.info("🔧 检测到可能需要新工具，尝试自动生成...")
            
            # 分析用户需求，生成工具
            tool_name = self._extract_tool_name(user_input)
            if tool_name:
                logger.info(f"   生成工具: {tool_name}")
                
                # 生成工具描述
                tool_description = f"""
                创建一个工具来完成用户的请求：{user_input}
                
                要求：
                - 工具名称：{tool_name}
                - 实现用户需要的功能
                - 包含必要的错误处理
                - 使用合适的系统命令或库
                """
                
                # 生成并加载工具
                tool_file = self.tool_generator.generate_tool(tool_description, tool_name)
                
                if tool_file:
                    try:
                        tool = self.tool_generator.load_tool(tool_file)
                        self.tools.register(tool)
                        self.auto_generated_tools.append(tool_name)
                        
                        logger.info(f"   ✓ 工具 '{tool_name}' 已生成并注册")
                        logger.info(f"   ✓ 重新处理请求...")
                        
                        # 重新处理
                        result = await self.process(user_input, **kwargs)
                        result['auto_generated_tool'] = tool_name
                    
                    except Exception as e:
                        logger.error(f"   ✗ 工具加载失败: {e}")
        
        return result
    
    def _extract_tool_name(self, user_input: str) -> Optional[str]:
        """从用户输入提取工具名称"""
        # 简单规则：提取动作词
        actions = {
            '打开': 'open',
            '关闭': 'close',
            '启动': 'start',
            '停止': 'stop',
            '查看': 'view',
            '显示': 'show',
            '获取': 'get',
            '设置': 'set',
        }
        
        for cn, en in actions.items():
            if cn in user_input:
                # 提取目标
                if 'chrome' in user_input.lower() or '浏览器' in user_input:
                    return f"{en}_chrome"
                elif 'vscode' in user_input.lower() or 'code' in user_input.lower():
                    return f"{en}_vscode"
                elif '文件' in user_input:
                    return f"{en}_file"
                else:
                    return f"{en}_app"
        
        return None


async def main():
    """测试完整工作流"""
    
    print("="*60)
    print("Genesis - 自动工具生成工作流测试")
    print("="*60)
    
    api_key = os.getenv('DEEPSEEK_API_KEY')
    if not api_key:
        raise RuntimeError("请先设置环境变量 DEEPSEEK_API_KEY")

    agent = GenesisWithAutoTools(api_key=api_key)
    
    # 测试：打开 Chrome（没有这个工具）
    print("\n测试命令: 打开我的chrome浏览器\n")
    
    result = await agent.process_with_auto_tools(
        user_input="打开我的chrome浏览器",
        intent_type="task"
    )
    
    print("\n" + "="*60)
    print("结果:")
    print("="*60)
    print(result['response'])
    
    if 'auto_generated_tool' in result:
        print(f"\n✓ 自动生成了工具: {result['auto_generated_tool']}")
    
    print(f"\n当前工具数: {len(agent.tools)}")
    print(f"自动生成的工具: {agent.auto_generated_tools}")


if __name__ == '__main__':
    asyncio.run(main())
