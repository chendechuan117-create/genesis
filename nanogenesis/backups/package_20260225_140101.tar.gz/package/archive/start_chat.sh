#!/bin/bash
# Genesis 对话启动脚本

API_KEY="${DEEPSEEK_API_KEY:-$1}"

if [ -z "$API_KEY" ]; then
    echo "请提供 API key:"
    echo "  方式1: export DEEPSEEK_API_KEY='your-key'"
    echo "  方式2: ./start_chat.sh your-key"
    exit 1
fi

cd "$(dirname "$0")" || exit 1

echo "启动 Genesis 对话..."
DEEPSEEK_API_KEY="$API_KEY" python3 chat.py
