
import sqlite3
import json
import logging
import uuid
import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional
import asyncio
from .interface import SessionStore

logger = logging.getLogger(__name__)

class SessionManager(SessionStore):
    """
    Manages active session context with reliable persistence.
    Prevents 'Amnesia' by syncing every turn to SQLite.
    """
    
    def __init__(self, db_path: str = None, session_id: str = None):
        if db_path:
            self.db_path = Path(db_path)
        else:
            self.db_path = Path.home() / ".nanogenesis" / "sessions.sqlite"
            
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.session_id = session_id or str(uuid.uuid4())
        
        self._init_db()
        logger.info(f"SessionManager initialized: {self.session_id}")
        
    def _get_conn(self):
        return sqlite3.connect(self.db_path, check_same_thread=False)

    def _init_db(self):
        with self._get_conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    tools_used TEXT,
                    timestamp TEXT NOT NULL,
                    turn_index INTEGER NOT NULL
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_session_id ON sessions(session_id)")
            
    async def save_turn(self, user_input: str, assistant_response: str, tools_used: List[str] = None) -> None:
        """Save a full conversation turn atomically"""
        now = datetime.datetime.now().isoformat()
        tools_json = json.dumps(tools_used or [])
        
        def _sync_write():
            with self._get_conn() as conn:
                # Get next index
                cursor = conn.execute("SELECT MAX(turn_index) FROM sessions WHERE session_id = ?", (self.session_id,))
                last_idx = cursor.fetchone()[0] or 0
                
                # User Message
                conn.execute("""
                    INSERT INTO sessions (session_id, role, content, timestamp, turn_index)
                    VALUES (?, ?, ?, ?, ?)
                """, (self.session_id, 'user', user_input, now, last_idx + 1))
                
                # Assistant Message
                conn.execute("""
                    INSERT INTO sessions (session_id, role, content, tools_used, timestamp, turn_index)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (self.session_id, 'assistant', assistant_response, tools_json, now, last_idx + 2))
                
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, _sync_write)
        logger.debug(f"Saved turn to session {self.session_id}")
        
    async def get_full_history(self) -> List[Dict[str, Any]]:
        """Retrieve full history for the current session"""
        def _sync_read():
            with self._get_conn() as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.execute("""
                    SELECT role, content, tools_used 
                    FROM sessions 
                    WHERE session_id = ? 
                    ORDER BY turn_index ASC
                """, (self.session_id,))
                
                history = []
                for row in cursor:
                    msg = {
                        "role": row['role'],
                        "content": row['content']
                    }
                    if row['tools_used']:
                         msg['tools_used'] = json.loads(row['tools_used'])
                    history.append(msg)
                return history

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _sync_read)

    async def get_recent_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Get the most recent N messages"""
        def _sync_read():
            with self._get_conn() as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.execute("""
                    SELECT role, content, tools_used 
                    FROM sessions 
                    WHERE session_id = ? 
                    ORDER BY turn_index DESC
                    LIMIT ?
                """, (self.session_id, limit))
                
                history = []
                for row in cursor:
                    msg = {
                        "role": row['role'],
                        "content": row['content']
                    }
                    if row['tools_used']:
                        msg['tools_used'] = json.loads(row['tools_used'])
                    history.append(msg)
                return list(reversed(history))

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _sync_read)
        
    async def restore_last_session(self) -> bool:
        """Attempt to restore the most recently active session"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.restore_last_session_sync)
        
    def restore_last_session_sync(self) -> bool:
        """Synchronous version for __init__ usage"""
        with self._get_conn() as conn:
            cursor = conn.execute("SELECT session_id FROM sessions ORDER BY id DESC LIMIT 1")
            row = cursor.fetchone()
            if row:
                last_id = row[0]
                logger.info(f"Restoring previous session: {last_id}")
                self.session_id = last_id
                return True
            return False
