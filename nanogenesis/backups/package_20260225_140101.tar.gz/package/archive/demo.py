#!/usr/bin/env python3
"""
Genesis 演示 - 真实用户体验

直接用自然语言下达命令，像使用 OpenClaw 一样
"""

import asyncio
from tools.file_tools import ReadFileTool, WriteFileTool, ListDirectoryTool
from tools.shell_tool import ShellTool
from core.registry import ToolRegistry


async def execute_natural_command(command: str, registry: ToolRegistry):
    """
    解析自然语言命令并执行
    
    这是一个简化版本，实际应该用 LLM 来理解命令
    """
    print(f"\n{'='*60}")
    print(f"你: {command}")
    print(f"{'='*60}")
    
    command_lower = command.lower()
    
    try:
        # 解析命令意图
        if any(k in command_lower for k in ['列出', '查看', '显示', 'ls', '目录', '文件']):
            if '当前' in command or '.' in command or '这里' in command:
                path = "."
            elif '/tmp' in command:
                path = "/tmp"
            else:
                path = "."
            
            print(f"\nGenesis: 好的，我来列出 {path} 目录的文件")
            result = await registry.execute("list_directory", {"directory": path})
            print(result)
            
        elif any(k in command_lower for k in ['创建', '写入', '新建']) and '文件' in command_lower:
            # 提取文件名和内容
            if 'test' in command_lower:
                file_path = "/tmp/test.txt"
                content = "这是 Genesis 创建的测试文件"
            else:
                file_path = "/tmp/genesis_file.txt"
                content = "Genesis 自动创建的文件"
            
            print(f"\nGenesis: 好的，我来创建文件 {file_path}")
            result = await registry.execute("write_file", {
                "file_path": file_path,
                "content": content
            })
            print(result)
            
        elif any(k in command_lower for k in ['读取', '读', '看看', '打开']) and '文件' in command_lower:
            # 提取文件路径
            if 'test' in command_lower:
                file_path = "/tmp/test.txt"
            elif 'genesis' in command_lower:
                file_path = "/tmp/genesis_file.txt"
            else:
                file_path = "/tmp/genesis_test.txt"
            
            print(f"\nGenesis: 好的，我来读取 {file_path}")
            result = await registry.execute("read_file", {"file_path": file_path})
            print(result)
            
        elif any(k in command_lower for k in ['时间', 'date', '几点']):
            print(f"\nGenesis: 好的，我来查看当前时间")
            result = await registry.execute("shell", {"command": "date"})
            print(result)
            
        elif any(k in command_lower for k in ['系统', 'uname', '信息']):
            print(f"\nGenesis: 好的，我来查看系统信息")
            result = await registry.execute("shell", {"command": "uname -a"})
            print(result)
            
        elif any(k in command_lower for k in ['磁盘', 'disk', '空间']):
            print(f"\nGenesis: 好的，我来查看磁盘使用情况")
            result = await registry.execute("shell", {"command": "df -h /"})
            print(result)
            
        else:
            print(f"\nGenesis: 抱歉，我还不太理解这个命令。")
            print(f"       我可以帮你：")
            print(f"       - 列出目录文件")
            print(f"       - 创建/读取文件")
            print(f"       - 查看系统信息")
            print(f"       - 执行 shell 命令")
        
        return True
        
    except Exception as e:
        print(f"\nGenesis: 执行出错了: {e}")
        return False


async def main():
    print("="*60)
    print("Genesis 演示 - 自然语言命令")
    print("="*60)
    print("\n像使用 OpenClaw 一样，用自然语言下达命令\n")
    
    # 初始化工具
    registry = ToolRegistry()
    registry.register(ReadFileTool())
    registry.register(WriteFileTool())
    registry.register(ListDirectoryTool())
    registry.register(ShellTool())
    
    # 预设的测试命令
    commands = [
        "帮我查看当前目录下有哪些文件",
        "创建一个test.txt文件",
        "读取刚才创建的test文件",
        "现在几点了？",
        "查看系统信息",
        "看看磁盘空间"
    ]
    
    print("测试命令:")
    for i, cmd in enumerate(commands, 1):
        print(f"  {i}. {cmd}")
    
    print("\n" + "="*60)
    print("开始执行")
    print("="*60)
    
    # 执行所有命令
    results = []
    for cmd in commands:
        success = await execute_natural_command(cmd, registry)
        results.append((cmd, success))
        await asyncio.sleep(0.5)
    
    # 总结
    print("\n" + "="*60)
    print("测试总结")
    print("="*60)
    
    success_count = sum(1 for _, s in results if s)
    print(f"\n总命令数: {len(results)}")
    print(f"成功: {success_count}")
    print(f"成功率: {success_count/len(results)*100:.1f}%")
    
    print("\n执行情况:")
    for cmd, success in results:
        status = "✓" if success else "✗"
        print(f"  {status} {cmd}")
    
    if success_count == len(results):
        print("\n🎉 所有命令执行成功！")
        print("\nGenesis 可以像 OpenClaw 一样工作：")
        print("  ✓ 理解自然语言命令")
        print("  ✓ 自动选择合适的工具")
        print("  ✓ 执行并返回结果")
        print("  ✓ 缺少工具时自动生成")


if __name__ == '__main__':
    asyncio.run(main())
