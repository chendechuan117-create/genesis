#!/usr/bin/env python3
"""
测试简单命令
"""

import asyncio
import os
from agent_with_polyhedron import NanoGenesisWithPolyhedron


async def test():
    api_key = os.getenv('DEEPSEEK_API_KEY')
    if not api_key:
        raise RuntimeError("请先设置环境变量 DEEPSEEK_API_KEY")

    agent = NanoGenesisWithPolyhedron(api_key=api_key)
    
    print("="*60)
    print("测试简单命令: 打开我的chrome")
    print("="*60)
    
    result = await agent.process(
        user_input="打开我的chrome",
        intent_type="task"
    )
    
    print("\n响应:")
    print(result['response'])
    
    print("\n性能指标:")
    print(f"迭代次数: {result['metrics'].iterations}")
    print(f"总耗时: {result['metrics'].total_time:.2f}s")
    print(f"使用多面体: {result['use_polyhedron']}")


if __name__ == '__main__':
    asyncio.run(test())
