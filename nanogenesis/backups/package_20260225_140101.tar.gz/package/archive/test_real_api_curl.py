"""
使用 curl 调用 DeepSeek API
"""

import os
import subprocess
import json
from intelligence.protocol_encoder import ProtocolEncoder
from intelligence.context_filter import LocalLLMContextFilter, MockLocalLLM
from intelligence.user_persona import UserPersonaLearner
from intelligence.polyhedron_prompt import PolyhedronPromptBuilder, ComplexityEstimator


def call_deepseek_with_curl(api_key: str, system_prompt: str, user_message: str):
    """使用 curl 调用 API"""
    
    data = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message}
        ],
        "temperature": 0.7,
        "max_tokens": 1000
    }
    
    cmd = [
        'curl', '-X', 'POST',
        'https://api.deepseek.com/v1/chat/completions',
        '-H', f'Authorization: Bearer {api_key}',
        '-H', 'Content-Type: application/json',
        '-d', json.dumps(data)
    ]
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    if result.returncode == 0:
        return json.loads(result.stdout)
    else:
        raise Exception(f"curl 失败: {result.stderr}")


def main():
    api_key = os.getenv('DEEPSEEK_API_KEY')
    if not api_key:
        raise RuntimeError("请先设置环境变量 DEEPSEEK_API_KEY")
    
    print("="*60)
    print("多面体框架 - 真实 API 测试")
    print("="*60)
    
    # 初始化
    encoder = ProtocolEncoder()
    filter = LocalLLMContextFilter(local_llm=MockLocalLLM(), max_files=5)
    learner = UserPersonaLearner()
    builder = PolyhedronPromptBuilder(encoder=encoder)
    estimator = ComplexityEstimator()
    
    user_input = "Docker 容器启动失败，提示 permission denied，我该怎么解决？"
    
    available_contexts = {
        'docker_perm': 'Docker 权限问题：用户不在 docker 组，运行 sudo usermod -aG docker $USER',
        'linux_perm': 'Linux 权限：chmod 修改权限，chown 修改所有者',
        'docker_compose': 'Docker Compose 配置：user: "${UID}:${GID}"',
    }
    
    print(f"\n用户问题: {user_input}\n")
    
    # 处理流程
    selected = filter.filter_context(user_input, available_contexts)
    
    encoded = encoder.encode({
        'problem': user_input,
        'env_info': {'os': 'linux'},
        'diagnosis': 'User permission issue',
        'strategy': 'Add user to docker group',
        'user_pref': 'config'
    })
    
    complexity = estimator.estimate(user_input)
    use_polyhedron = builder.should_use_polyhedron("problem", 0.7, complexity)
    
    user_persona = learner.generate_persona_summary()
    system_prompt = builder.build_system_prompt(
        user_persona,
        {'budget': 0, 'environment': 'Linux', 'preferences': '本地化'},
        include_polyhedron=use_polyhedron
    )
    
    user_message_parts = [f"编码上下文：{encoded}"]
    if selected:
        user_message_parts.append("\n相关记忆：")
        for key, content in list(selected.items())[:2]:
            user_message_parts.append(f"\n### {key}\n{content}")
    if use_polyhedron:
        user_message_parts.append("\n请按多面体坍缩框架思考，给出最优解。")
    
    user_message = '\n'.join(user_message_parts)
    
    print(f"复杂度: {complexity}")
    print(f"使用多面体: {'是' if use_polyhedron else '否'}")
    print(f"System Prompt: {len(system_prompt)} 字符")
    print(f"User Message: {len(user_message)} 字符")
    print(f"\n调用 API...\n")
    
    try:
        result = call_deepseek_with_curl(api_key, system_prompt, user_message)
        
        response_text = result['choices'][0]['message']['content']
        usage = result['usage']
        
        print("="*60)
        print("AI 响应:")
        print("="*60)
        print(response_text)
        
        print("\n" + "="*60)
        print("Token 统计:")
        print("="*60)
        print(f"输入: {usage['prompt_tokens']}")
        print(f"输出: {usage['completion_tokens']}")
        print(f"总计: {usage['total_tokens']}")
        
        if 'prompt_cache_hit_tokens' in usage:
            print(f"缓存命中: {usage['prompt_cache_hit_tokens']}")
            print(f"缓存未命中: {usage['prompt_cache_miss_tokens']}")
        
        print("\n✅ 测试成功！")
        
    except Exception as e:
        print(f"❌ 失败: {e}")


if __name__ == '__main__':
    main()
