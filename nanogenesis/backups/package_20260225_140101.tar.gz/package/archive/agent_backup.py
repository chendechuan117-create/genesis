"""
NanoGenesis 主类 - 整合所有核心组件
"""

from typing import Optional, Dict, Any
import logging

from .core import (
    ToolRegistry,
    AgentLoop,
    SimpleContextBuilder,
    LiteLLMProvider,
    PerformanceMetrics
)

logger = logging.getLogger(__name__)


class NanoGenesis:
    """
    NanoGenesis - 自进化的轻量级智能 Agent
    
    核心特性：
    1. 省 Token - 多层缓存优化
    2. 能干活 - 工具 + 智能诊断
    3. 会自我迭代 - 提示词、行为、工具自优化
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model: str = "deepseek/deepseek-chat",
        max_iterations: int = 10
    ):
        """
        初始化 NanoGenesis
        
        Args:
            api_key: LLM API Key
            base_url: LLM API Base URL
            model: 使用的模型
            max_iterations: 最大迭代次数
        """
        
        # 核心组件
        self.tools = ToolRegistry()
        self.context = SimpleContextBuilder()
        
        # 优先使用 NativeHTTPProvider (因为 LiteLLM 可能未安装)
        from .core import NativeHTTPProvider, LITELLM_AVAILABLE
        
        if LITELLM_AVAILABLE:
            self.provider = LiteLLMProvider(
                api_key=api_key,
                base_url=base_url,
                default_model=model
            )
        else:
            logger.info("LiteLLM 未安装，使用 NativeHTTPProvider")
            self.provider = NativeHTTPProvider(
                api_key=api_key,
                base_url=base_url,
                default_model="deepseek-chat" # DeepSeek API 默认模型
            )
            
        self.loop = AgentLoop(
            tools=self.tools,
            context=self.context,
            provider=self.provider,
            max_iterations=max_iterations
        )
        
        # 性能监控
        self.metrics_history = []
        
        # 注册基础工具
        self._register_basic_tools()
        
        logger.debug("✓ NanoGenesis 初始化完成")
    
    def _register_basic_tools(self):
        """注册基础工具"""
        import sys
        from pathlib import Path
        
        # 添加路径
        sys.path.insert(0, str(Path(__file__).parent))
        
        try:
            # 基础工具
            from tools.file_tools import (
                ReadFileTool,
                WriteFileTool,
                AppendFileTool,
                ListDirectoryTool
            )
            from tools.shell_tool import ShellTool
            from tools.web_tool import WebSearchTool
            
            # 智能工具
            from intelligence.diagnostic_tool import DiagnosticTool
            from intelligence.strategy_tool import StrategySearchTool
            
            # 注册文件工具
            self.tools.register(ReadFileTool())
            self.tools.register(WriteFileTool())
            self.tools.register(AppendFileTool())
            self.tools.register(ListDirectoryTool())
            
            # 注册 Shell 工具
            self.tools.register(ShellTool())
            
            # 注册 Web 工具
            self.tools.register(WebSearchTool())
            
            # 注册智能工具
            self.tools.register(DiagnosticTool())
            self.tools.register(StrategySearchTool())
            
            logger.info(f"✓ 已注册 {len(self.tools)} 个工具")
        
        except Exception as e:
            logger.warning(f"注册工具时出错: {e}")
    
    async def process(
        self,
        user_input: str,
        user_context: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        处理用户输入
        
        Args:
            user_input: 用户输入
            user_context: 用户上下文（可选）
            **kwargs: 其他参数
        
        Returns:
            {
                'response': 响应内容,
                'metrics': 性能指标,
                'success': 是否成功
            }
        """
        
        logger.debug(f"处理用户输入: {user_input[:50]}...")
        
        try:
            # 运行 Agent 循环
            response, metrics = await self.loop.run(
                user_input=user_input,
                user_context=user_context,
                **kwargs
            )
            
            # 记录性能指标
            self.metrics_history.append(metrics)
            
            return {
                'response': response,
                'metrics': metrics,
                'success': metrics.success
            }
        
        except Exception as e:
            logger.error(f"处理失败: {e}")
            return {
                'response': f"Error: {str(e)}",
                'metrics': None,
                'success': False
            }
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        
        if not self.metrics_history:
            return {
                'total_interactions': 0,
                'avg_tokens': 0,
                'avg_time': 0,
                'success_rate': 0
            }
        
        total = len(self.metrics_history)
        total_tokens = sum(m.tokens for m in self.metrics_history)
        total_time = sum(m.time for m in self.metrics_history)
        success_count = sum(1 for m in self.metrics_history if m.success)
        
        return {
            'total_interactions': total,
            'avg_tokens': total_tokens / total,
            'avg_time': total_time / total,
            'success_rate': success_count / total,
            'total_tools_used': sum(len(m.tools_used) for m in self.metrics_history)
        }
    
    def register_tool(self, tool) -> None:
        """注册工具"""
        self.tools.register(tool)
    
    def update_system_prompt(self, new_prompt: str) -> None:
        """更新系统提示词"""
        self.context.update_system_prompt(new_prompt)
