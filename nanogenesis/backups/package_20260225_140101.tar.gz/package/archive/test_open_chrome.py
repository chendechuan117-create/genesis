#!/usr/bin/env python3
"""
测试：帮我打开chrome
"""

import asyncio
import os
from agent_with_polyhedron import NanoGenesisWithPolyhedron


async def test():
    print("="*60)
    print("测试：帮我打开chrome")
    print("="*60)

    api_key = os.getenv('DEEPSEEK_API_KEY')
    if not api_key:
        raise RuntimeError("请先设置环境变量 DEEPSEEK_API_KEY")

    agent = NanoGenesisWithPolyhedron(api_key=api_key)
    
    print("\n用户: 帮我打开chrome\n")
    
    try:
        result = await agent.process(
            user_input="帮我打开chrome",
            intent_type="task"
        )
        
        print("Genesis:")
        print(result['response'])
        
        print("\n性能:")
        print(f"  迭代: {result['metrics'].iterations}")
        print(f"  耗时: {result['metrics'].total_time:.2f}s")
        print(f"  使用工具: {result['metrics'].tools_used}")
        
    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    asyncio.run(test())
