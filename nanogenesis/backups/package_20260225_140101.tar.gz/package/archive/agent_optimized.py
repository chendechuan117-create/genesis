"""
NanoGenesis 自优化版本 - 整合所有优化器
"""

import sys
from pathlib import Path
from typing import Optional, Dict, Any
import logging

sys.path.insert(0, str(Path(__file__).parent))

from core.base import PerformanceMetrics
from core.registry import ToolRegistry
from core.loop import AgentLoop
from core.context import SimpleContextBuilder
from core.provider import LiteLLMProvider

from optimization.prompt_optimizer import PromptOptimizer
from optimization.behavior_optimizer import BehaviorOptimizer
from optimization.tool_optimizer import ToolUsageOptimizer
from optimization.profile_evolution import UserProfileEvolution

logger = logging.getLogger(__name__)


class NanoGenesisOptimized:
    """
    NanoGenesis 自优化版本
    
    核心特性：
    1. 省 Token - 多层缓存优化 + 提示词自优化
    2. 能干活 - 工具 + 智能诊断 + 策略学习
    3. 会自我迭代 - 四重自优化机制
    """
    
    def __init__(
        self,
        user_id: str = "default_user",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model: str = "deepseek/deepseek-chat",
        max_iterations: int = 10,
        enable_optimization: bool = True
    ):
        """
        初始化
        
        Args:
            user_id: 用户 ID（用于用户画像）
            api_key: LLM API Key
            base_url: LLM API Base URL
            model: 使用的模型
            max_iterations: 最大迭代次数
            enable_optimization: 是否启用自优化
        """
        self.user_id = user_id
        self.enable_optimization = enable_optimization
        
        # 核心组件
        self.tools = ToolRegistry()
        self.context = SimpleContextBuilder()
        
        # Provider 可以后续设置（用于测试）
        if api_key or base_url:
            self.provider = LiteLLMProvider(
                api_key=api_key,
                base_url=base_url,
                default_model=model
            )
        else:
            # 默认使用 Mock Provider
            from core.provider import MockLLMProvider
            self.provider = MockLLMProvider()
        
        self.loop = AgentLoop(
            tools=self.tools,
            context=self.context,
            provider=self.provider,
            max_iterations=max_iterations
        )
        
        # 自优化组件
        if enable_optimization:
            self.prompt_optimizer = PromptOptimizer(optimize_interval=50)
            self.behavior_optimizer = BehaviorOptimizer()
            self.tool_optimizer = ToolUsageOptimizer()
            self.profile_evolution = UserProfileEvolution(user_id)
        else:
            self.prompt_optimizer = None
            self.behavior_optimizer = None
            self.tool_optimizer = None
            self.profile_evolution = None
        
        # 性能监控
        self.metrics_history = []
        
        # 注册工具
        self._register_tools()
        
        # 初始化系统提示词
        self._initialize_system_prompt()
        
        logger.debug(f"✓ NanoGenesis 初始化完成 (优化: {enable_optimization})")
    
    def _register_tools(self):
        """注册所有工具"""
        try:
            from tools.file_tools import (
                ReadFileTool, WriteFileTool,
                AppendFileTool, ListDirectoryTool
            )
            from tools.shell_tool import ShellTool
            from tools.web_tool import WebSearchTool
            from intelligence.diagnostic_tool import DiagnosticTool
            from intelligence.strategy_tool import StrategySearchTool
            
            self.tools.register(ReadFileTool())
            self.tools.register(WriteFileTool())
            self.tools.register(AppendFileTool())
            self.tools.register(ListDirectoryTool())
            self.tools.register(ShellTool())
            self.tools.register(WebSearchTool())
            self.tools.register(DiagnosticTool())
            self.tools.register(StrategySearchTool())
            
            logger.info(f"✓ 已注册 {len(self.tools)} 个工具")
        except Exception as e:
            logger.warning(f"注册工具时出错: {e}")
    
    def _initialize_system_prompt(self):
        """初始化系统提示词"""
        if self.enable_optimization and self.profile_evolution:
            # 使用用户画像生成个性化提示词
            adaptive_prompt = self.profile_evolution.generate_adaptive_prompt()
            self.context.update_system_prompt(adaptive_prompt)
        
        # 记录初始提示词
        if self.prompt_optimizer:
            self.prompt_optimizer.current_system_prompt = self.context.system_prompt
    
    async def process(
        self,
        user_input: str,
        problem_type: str = "general",
        **kwargs
    ) -> Dict[str, Any]:
        """
        处理用户输入（带自优化）
        
        Args:
            user_input: 用户输入
            problem_type: 问题类型（用于工具优化）
            **kwargs: 其他参数
        
        Returns:
            {
                'response': 响应内容,
                'metrics': 性能指标,
                'success': 是否成功,
                'optimization_info': 优化信息（如果有）
            }
        """
        logger.info(f"处理用户输入: {user_input[:50]}...")
        
        # 1. 获取工具推荐（如果启用优化）
        if self.enable_optimization and self.tool_optimizer:
            recommendations = self.tool_optimizer.get_tool_recommendations(problem_type)
            if recommendations.get('has_recommendation'):
                logger.debug(f"工具推荐: {recommendations['message']}")
        
        # 2. 运行 Agent 循环
        try:
            response, metrics = await self.loop.run(
                user_input=user_input,
                **kwargs
            )
            
            success = metrics.success
            
            # 3. 记录性能指标
            self.metrics_history.append(metrics)
            
            # 4. 自优化学习
            optimization_info = {}
            
            if self.enable_optimization:
                # 4.1 记录到提示词优化器
                if self.prompt_optimizer:
                    self.prompt_optimizer.log_interaction(
                        metrics, user_input, response, success
                    )
                
                # 4.2 记录到工具优化器
                if self.tool_optimizer:
                    self.tool_optimizer.record_sequence(
                        problem_type,
                        metrics.tools_used,
                        success,
                        {'tokens': metrics.tokens, 'time': metrics.time, 'iterations': metrics.iterations}
                    )
                
                # 4.3 记录到用户画像
                if self.profile_evolution:
                    self.profile_evolution.log_interaction({
                        'domain': problem_type,
                        'solution_type': self._infer_solution_type(response),
                        'tools_used': metrics.tools_used,
                        'success': success
                    })
                
                # 4.4 检查是否需要优化
                optimization_info = await self._check_and_optimize()
            
            return {
                'response': response,
                'metrics': metrics,
                'success': success,
                'optimization_info': optimization_info
            }
        
        except Exception as e:
            logger.error(f"处理失败: {e}")
            return {
                'response': f"Error: {str(e)}",
                'metrics': None,
                'success': False,
                'optimization_info': {}
            }
    
    async def _check_and_optimize(self) -> Dict[str, Any]:
        """检查并执行优化"""
        optimization_info = {}
        
        # 1. 提示词优化
        if self.prompt_optimizer and self.prompt_optimizer.should_optimize():
            result = await self.prompt_optimizer.optimize(self.context.system_prompt)
            
            if result and result.adopted:
                # 采用新提示词
                self.context.update_system_prompt(result.new_prompt)
                self.prompt_optimizer.current_system_prompt = result.new_prompt
                
                optimization_info['prompt_optimized'] = {
                    'token_saved': result.improvement['token_saved'],
                    'reason': result.reason
                }
                
                logger.info(f"✓ 提示词已优化: {result.reason}")
        
        # 2. 行为优化（策略库优化）
        if self.behavior_optimizer:
            if len(self.behavior_optimizer.strategies) > 0 and \
               len(self.behavior_optimizer.strategies) % 20 == 0:
                self.behavior_optimizer.optimize_strategies()
                optimization_info['strategies_optimized'] = True
        
        # 3. 用户画像进化
        if self.profile_evolution:
            changes = self.profile_evolution.evolve()
            if changes:
                # 更新系统提示词
                new_prompt = self.profile_evolution.generate_adaptive_prompt()
                self.context.update_system_prompt(new_prompt)
                
                optimization_info['profile_evolved'] = changes
                logger.info(f"✓ 用户画像已进化: {list(changes.keys())}")
        
        return optimization_info
    
    def _infer_solution_type(self, response: str) -> str:
        """推断解决方案类型"""
        response_lower = response.lower()
        
        if any(word in response_lower for word in ['config', 'yml', 'yaml', 'json', 'toml']):
            return 'config'
        elif any(word in response_lower for word in ['code', 'python', 'def ', 'class ']):
            return 'code'
        else:
            return 'unknown'
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        stats = {
            'total_interactions': len(self.metrics_history),
            'optimization_enabled': self.enable_optimization
        }
        
        if self.metrics_history:
            total_tokens = sum(m.tokens for m in self.metrics_history)
            total_time = sum(m.time for m in self.metrics_history)
            success_count = sum(1 for m in self.metrics_history if m.success)
            
            stats.update({
                'avg_tokens': total_tokens / len(self.metrics_history),
                'avg_time': total_time / len(self.metrics_history),
                'success_rate': success_count / len(self.metrics_history),
                'total_tools_used': sum(len(m.tools_used) for m in self.metrics_history)
            })
        
        # 优化器统计
        if self.enable_optimization:
            if self.prompt_optimizer:
                stats['prompt_optimizer'] = self.prompt_optimizer.get_stats()
            
            if self.behavior_optimizer:
                stats['behavior_optimizer'] = self.behavior_optimizer.get_stats()
            
            if self.tool_optimizer:
                stats['tool_optimizer'] = self.tool_optimizer.get_stats()
            
            if self.profile_evolution:
                stats['user_profile'] = self.profile_evolution.get_stats()
        
        return stats
    
    def get_optimization_report(self) -> str:
        """生成优化报告"""
        stats = self.get_stats()
        
        lines = [
            "=" * 60,
            "NanoGenesis 优化报告",
            "=" * 60,
            f"\n总交互次数: {stats['total_interactions']}",
        ]
        
        if stats['total_interactions'] > 0:
            lines.extend([
                f"平均 Token: {stats['avg_tokens']:.0f}",
                f"平均耗时: {stats['avg_time']:.2f}s",
                f"成功率: {stats['success_rate']:.1%}",
            ])
        
        if self.enable_optimization:
            lines.append("\n自优化统计:")
            
            if 'prompt_optimizer' in stats:
                po = stats['prompt_optimizer']
                lines.extend([
                    f"\n提示词优化:",
                    f"  - 优化次数: {po['total_optimizations']}",
                    f"  - 采用次数: {po['adopted_count']}",
                    f"  - 平均 Token 节省: {po['avg_token_saved']:.1%}",
                ])
            
            if 'behavior_optimizer' in stats:
                bo = stats['behavior_optimizer']
                lines.extend([
                    f"\n行为优化:",
                    f"  - 策略数量: {bo['total_strategies']}",
                    f"  - 平均成功率: {bo['avg_success_rate']:.1%}",
                    f"  - 总使用次数: {bo['total_uses']}",
                ])
            
            if 'tool_optimizer' in stats:
                to = stats['tool_optimizer']
                lines.extend([
                    f"\n工具优化:",
                    f"  - 问题类型: {to['problem_types']}",
                    f"  - 成功率: {to['success_rate']:.1%}",
                    f"  - 缓存最优序列: {to['cached_optimal']}",
                ])
            
            if 'user_profile' in stats:
                up = stats['user_profile']
                lines.extend([
                    f"\n用户画像:",
                    f"  - 专业领域: {', '.join(up['expertise']) if up['expertise'] else '未知'}",
                    f"  - 偏好工具: {', '.join(up['preferred_tools'][:3]) if up['preferred_tools'] else '未知'}",
                ])
        
        lines.append("=" * 60)
        
        return '\n'.join(lines)
