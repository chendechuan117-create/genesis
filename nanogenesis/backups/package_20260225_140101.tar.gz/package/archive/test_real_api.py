"""
真实 API 测试 - 使用 DeepSeek API
"""

import asyncio
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from agent_with_polyhedron import NanoGenesisWithPolyhedron


async def main():
    """真实 API 测试"""
    
    # 创建 Agent（使用真实 API）
    api_key = os.getenv('DEEPSEEK_API_KEY')
    if not api_key:
        raise RuntimeError("请先设置环境变量 DEEPSEEK_API_KEY")

    agent = NanoGenesisWithPolyhedron(
        api_key=api_key,
        base_url="https://api.deepseek.com",
        model="deepseek-chat",
        user_persona_path="./data/user_persona.json"
    )
    
    # 模拟记忆文件
    available_contexts = {
        'docker_perm_issue': '''Docker 容器权限问题常见原因：
1. 用户不在 docker 组
2. SELinux 阻止
3. 文件权限问题
解决方案：sudo usermod -aG docker $USER''',
        
        'linux_permissions': '''Linux 权限基础：
- rwx: 读写执行
- chmod: 修改权限
- chown: 修改所有者
- groups: 查看用户组''',
        
        'docker_compose_config': '''Docker Compose 配置示例：
services:
  app:
    user: "${UID}:${GID}"
    volumes:
      - ./data:/data''',
    }
    
    # 测试问题
    user_input = "Docker 容器启动失败，提示 permission denied，我该怎么解决？"
    
    print("="*60)
    print("真实 API 测试")
    print("="*60)
    print(f"\n用户问题: {user_input}\n")
    
    # 处理请求
    result = await agent.process(
        user_input=user_input,
        available_contexts=available_contexts,
        intent_type="problem"
    )
    
    # 显示结果
    print("\n" + "="*60)
    print("处理结果")
    print("="*60)
    
    print(f"\n复杂度: {result['complexity']}")
    print(f"使用多面体: {'是' if result['use_polyhedron'] else '否'}")
    print(f"筛选的上下文: {len(result['selected_contexts'])} 个")
    
    if result['selected_contexts']:
        print("\n筛选的记忆文件:")
        for ctx in result['selected_contexts']:
            print(f"  - {ctx}")
    
    print(f"\n编码上下文:\n{result['encoded_context']}")
    
    print("\n" + "="*60)
    print("AI 响应:")
    print("="*60)
    print(result['response'])
    
    # 显示性能指标
    print("\n" + "="*60)
    print("性能指标:")
    print("="*60)
    metrics = result['metrics']
    print(f"迭代次数: {metrics.iterations}")
    print(f"总耗时: {metrics.total_time:.2f}s")
    print(f"输入 tokens: {metrics.input_tokens}")
    print(f"输出 tokens: {metrics.output_tokens}")
    print(f"总 tokens: {metrics.total_tokens}")
    
    if metrics.tool_calls:
        print(f"\n工具调用: {len(metrics.tool_calls)} 次")
        for call in metrics.tool_calls:
            print(f"  - {call['function']['name']}")
    
    # 显示用户画像
    print("\n" + "="*60)
    print("用户画像更新:")
    print("="*60)
    print(agent.get_user_persona_summary())


if __name__ == '__main__':
    asyncio.run(main())
