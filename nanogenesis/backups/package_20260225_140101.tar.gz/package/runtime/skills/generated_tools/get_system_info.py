import sys
import platform
import psutil
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.base import Tool
from typing import Dict, Any

class GetSystemInfoTool(Tool):
    '''获取系统基本信息工具'''
    
    @property
    def name(self) -> str:
        return "get_system_info"
    
    @property
    def description(self) -> str:
        return "获取操作系统、CPU、内存等系统基本信息"
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "detail_level": {
                    "type": "string",
                    "enum": ["basic", "detailed"],
                    "description": "信息详细程度，basic只返回基本信息，detailed返回详细信息",
                    "default": "basic"
                }
            },
            "required": []
        }
    
    async def execute(self, **kwargs) -> str:
        '''执行工具'''
        detail_level = kwargs.get("detail_level", "basic")
        
        try:
            system_info = self._collect_system_info(detail_level)
            return self._format_output(system_info, detail_level)
        except Exception as e:
            return f"获取系统信息时出错: {str(e)}"
    
    def _collect_system_info(self, detail_level: str) -> Dict[str, Any]:
        """收集系统信息"""
        info = {}
        
        # 操作系统信息
        info["os"] = {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
        }
        
        if detail_level == "detailed":
            info["os"]["platform"] = platform.platform()
            info["os"]["architecture"] = platform.architecture()
        
        # CPU信息
        cpu_info = {
            "physical_cores": psutil.cpu_count(logical=False),
            "logical_cores": psutil.cpu_count(logical=True),
            "cpu_percent": psutil.cpu_percent(interval=0.1),
        }
        
        if detail_level == "detailed":
            cpu_freq = psutil.cpu_freq()
            cpu_info.update({
                "cpu_freq_current": cpu_freq.current if cpu_freq else None,
                "cpu_freq_max": cpu_freq.max if cpu_freq else None,
                "cpu_freq_min": cpu_freq.min if cpu_freq else None,
                "cpu_stats": psutil.cpu_stats()._asdict(),
                "cpu_times": psutil.cpu_times_percent()._asdict(),
            })
        
        info["cpu"] = cpu_info
        
        # 内存信息
        memory = psutil.virtual_memory()
        swap = psutil.swap_memory()
        
        info["memory"] = {
            "total": self._format_bytes(memory.total),
            "available": self._format_bytes(memory.available),
            "used": self._format_bytes(memory.used),
            "percent": memory.percent,
            "swap_total": self._format_bytes(swap.total),
            "swap_used": self._format_bytes(swap.used),
            "swap_percent": swap.percent,
        }
        
        if detail_level == "detailed":
            info["memory"]["detailed"] = memory._asdict()
            info["memory"]["swap_detailed"] = swap._asdict()
        
        # 磁盘信息
        disk_info = []
        for partition in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(partition.mountpoint)
                disk_info.append({
                    "device": partition.device,
                    "mountpoint": partition.mountpoint,
                    "fstype": partition.fstype,
                    "total": self._format_bytes(usage.total),
                    "used": self._format_bytes(usage.used),
                    "free": self._format_bytes(usage.free),
                    "percent": usage.percent,
                })
            except PermissionError:
                continue
        
        info["disk"] = disk_info
        
        # 网络信息
        if detail_level == "detailed":
            net_info = psutil.net_if_addrs()
            net_stats = psutil.net_if_stats()
            info["network"] = {
                "interfaces": list(net_info.keys()),
                "io_counters": psutil.net_io_counters()._asdict(),
            }
        
        # Python环境信息
        info["python"] = {
            "version": platform.python_version(),
            "implementation": platform.python_implementation(),
            "compiler": platform.python_compiler(),
        }
        
        return info
    
    def _format_bytes(self, bytes_value: int) -> str:
        """格式化字节大小为易读格式"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes_value < 1024.0:
                return f"{bytes_value:.2f} {unit}"
            bytes_value /= 1024.0
        return f"{bytes_value:.2f} PB"
    
    def _format_output(self, info: Dict[str, Any], detail_level: str) -> str:
        """格式化输出信息"""
        output_lines = []
        
        # 操作系统信息
        output_lines.append("=== 操作系统信息 ===")
        os_info = info["os"]
        output_lines.append(f"系统: {os_info['system']} {os_info['release']}")
        output_lines.append(f"版本: {os_info['version']}")
        output_lines.append(f"架构: {os_info['machine']}")
        
        if detail_level == "detailed":
            output_lines.append(f"平台: {os_info.get('platform', 'N/A')}")
            output_lines.append(f"处理器: {os_info['processor']}")
        
        # CPU信息
        output_lines.append("\n=== CPU信息 ===")
        cpu_info = info["cpu"]
        output_lines.append(f"物理核心数: {cpu_info['physical_cores']}")
        output_lines.append(f"逻辑核心数: {cpu_info['logical_cores']}")
        output_lines.append(f"CPU使用率: {cpu_info['cpu_percent']}%")
        
        if detail_level == "detailed":
            if cpu_info.get('cpu_freq_current'):
                output_lines.append(f"当前频率: {cpu_info['cpu_freq_current']:.2f} MHz")
            if cpu_info.get('cpu_freq_max'):
                output_lines.append(f"最大频率: {cpu_info['cpu_freq_max']:.2f} MHz")
        
        # 内存信息
        output_lines.append("\n=== 内存信息 ===")
        mem_info = info["memory"]
        output_lines.append(f"总内存: {mem_info['total']}")
        output_lines.append(f"可用内存: {mem_info['available']}")
        output_lines.append(f"已用内存: {mem_info['used']} ({mem_info['percent']}%)")
        output_lines.append(f"交换空间: {mem_info['swap_total']} (已用: {mem_info['swap_used']}, {mem_info['swap_percent']}%)")
        
        # 磁盘信息
        output_lines.append("\n=== 磁盘信息 ===")
        for i, disk in enumerate(info["disk"], 1):
            output_lines.append(f"磁盘 {i}: {disk['device']} ({disk['fstype']})")
            output_lines.append(f"  挂载点: {disk['mountpoint']}")
            output_lines.append(f"  总空间: {disk['total']}")
            output_lines.append(f"  已用空间: {disk['used']} ({disk['percent']}%)")
            output_lines.append(f"  可用空间: {disk['free']}")
        
        # 网络信息
        if detail_level == "detailed" and "network" in info:
            output_lines.append("\n=== 网络信息 ===")
            net_info = info["network"]
            output_lines.append(f"网络接口: {', '.join(net_info['interfaces'])}")
        
        # Python环境信息
        output_lines.append("\n=== Python环境 ===")
        py_info = info["python"]
        output_lines.append(f"Python版本: {py_info['version']}")
        output_lines.append(f"实现: {py_info['implementation']}")
        
        if detail_level == "detailed":
            output_lines.append(f"编译器: {py_info['compiler']}")
        
        return "\n".join(output_lines)
