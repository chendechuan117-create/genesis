"""
测试优化后的本地 LLM 筛选（使用 7B 模型）
"""

import subprocess
import json
from intelligence.context_filter import LocalLLMContextFilter


class OllamaLLM:
    """Ollama 本地 LLM"""
    
    def __init__(self, model="qwen2.5:7b"):
        self.model = model
    
    def generate(self, prompt: str, max_tokens: int = 100) -> str:
        """调用 Ollama 生成"""
        
        data = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "num_predict": max_tokens,
                "temperature": 0.1,  # 降低温度，提高准确性
                "top_p": 0.9
            }
        }
        
        cmd = [
            'curl', '-s', '-X', 'POST',
            'http://localhost:11434/api/generate',
            '-H', 'Content-Type: application/json',
            '-d', json.dumps(data)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            response = json.loads(result.stdout)
            return response.get('response', '')
        else:
            raise Exception(f"Ollama 调用失败: {result.stderr}")


def test_filtering(model_name="qwen2.5:7b"):
    """测试筛选"""
    
    print(f"\n{'='*60}")
    print(f"测试模型: {model_name}")
    print(f"{'='*60}")
    
    # 创建 LLM
    ollama = OllamaLLM(model=model_name)
    filter = LocalLLMContextFilter(local_llm=ollama, max_files=5)
    
    # 测试数据
    user_input = "Docker 容器启动失败，提示 permission denied，我该怎么解决？"
    
    available_files = [
        '/memory/docker_issues.md',
        '/memory/python_errors.md',
        '/memory/git_conflicts.md',
        '/memory/docker_networking.md',
        '/memory/linux_permissions.md',
        '/memory/database_queries.md',
        '/memory/web_apis.md',
        '/memory/docker_compose.md',
        '/memory/kubernetes.md',
        '/memory/ci_cd.md',
    ]
    
    file_summaries = {
        '/memory/docker_issues.md': 'Docker 常见问题和解决方案，包括权限、网络、端口等',
        '/memory/python_errors.md': 'Python 错误处理和调试技巧',
        '/memory/git_conflicts.md': 'Git 合并冲突解决方法',
        '/memory/docker_networking.md': 'Docker 网络配置详解',
        '/memory/linux_permissions.md': 'Linux 文件和用户权限管理',
        '/memory/database_queries.md': 'SQL 查询优化和索引',
        '/memory/web_apis.md': 'REST API 开发最佳实践',
        '/memory/docker_compose.md': 'Docker Compose 配置示例',
        '/memory/kubernetes.md': 'Kubernetes 部署和管理',
        '/memory/ci_cd.md': 'CI/CD 流水线配置',
    }
    
    print(f"\n用户问题: {user_input}")
    print(f"可用文件: {len(available_files)} 个")
    
    # 测试筛选
    print("\n筛选中...")
    selected = filter.filter_files(user_input, available_files, file_summaries)
    
    print(f"\n筛选结果: {len(selected)} 个文件")
    
    # 评估准确性
    relevant_files = {
        '/memory/docker_issues.md': '高度相关',
        '/memory/linux_permissions.md': '高度相关',
        '/memory/docker_compose.md': '相关',
        '/memory/docker_networking.md': '中等相关',
    }
    
    correct = 0
    for f in selected:
        relevance = relevant_files.get(f, '不相关')
        symbol = '✓' if relevance in ['高度相关', '相关'] else '✗'
        print(f"  {symbol} {f} - {relevance}")
        if relevance in ['高度相关', '相关']:
            correct += 1
    
    accuracy = (correct / len(selected) * 100) if selected else 0
    print(f"\n准确率: {accuracy:.1f}% ({correct}/{len(selected)})")
    
    return accuracy


def main():
    print("="*60)
    print("本地 LLM 筛选优化测试")
    print("="*60)
    
    # 测试 7B 模型
    accuracy_7b = test_filtering("qwen2.5:7b")
    
    # 对比规则筛选
    print(f"\n{'='*60}")
    print("规则筛选对比")
    print(f"{'='*60}")
    
    from intelligence.context_filter import LocalLLMContextFilter
    
    filter_rule = LocalLLMContextFilter(local_llm=None, max_files=5)
    
    user_input = "Docker 容器启动失败，提示 permission denied，我该怎么解决？"
    available_files = [
        '/memory/docker_issues.md',
        '/memory/python_errors.md',
        '/memory/git_conflicts.md',
        '/memory/docker_networking.md',
        '/memory/linux_permissions.md',
        '/memory/database_queries.md',
        '/memory/web_apis.md',
        '/memory/docker_compose.md',
        '/memory/kubernetes.md',
        '/memory/ci_cd.md',
    ]
    
    file_summaries = {
        '/memory/docker_issues.md': 'Docker 常见问题',
        '/memory/linux_permissions.md': 'Linux 权限管理',
        '/memory/docker_compose.md': 'Docker Compose 配置',
    }
    
    selected = filter_rule.filter_files(user_input, available_files, file_summaries)
    
    print(f"\n规则筛选结果: {len(selected)} 个文件")
    
    relevant_files = {
        '/memory/docker_issues.md': '高度相关',
        '/memory/linux_permissions.md': '高度相关',
        '/memory/docker_compose.md': '相关',
        '/memory/docker_networking.md': '中等相关',
    }
    
    correct = 0
    for f in selected:
        relevance = relevant_files.get(f, '不相关')
        symbol = '✓' if relevance in ['高度相关', '相关'] else '✗'
        print(f"  {symbol} {f} - {relevance}")
        if relevance in ['高度相关', '相关']:
            correct += 1
    
    accuracy_rule = (correct / len(selected) * 100) if selected else 0
    print(f"\n准确率: {accuracy_rule:.1f}% ({correct}/{len(selected)})")
    
    # 总结
    print(f"\n{'='*60}")
    print("总结")
    print(f"{'='*60}")
    print(f"7B 模型准确率: {accuracy_7b:.1f}%")
    print(f"规则筛选准确率: {accuracy_rule:.1f}%")
    
    if accuracy_7b > accuracy_rule:
        print("\n✅ 7B 模型表现更好，建议使用")
    elif accuracy_7b == accuracy_rule:
        print("\n⚖️ 两者表现相当，规则筛选更快")
    else:
        print("\n✅ 规则筛选表现更好，建议使用")


if __name__ == '__main__':
    main()
