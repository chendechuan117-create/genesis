import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.base import Tool
from typing import Dict, Any
import random
from datetime import datetime

class GetWeatherTool(Tool):
    '''获取指定城市的天气信息'''
    
    @property
    def name(self) -> str:
        return "get_weather"
    
    @property
    def description(self) -> str:
        return "获取指定城市的天气信息，包括温度、湿度、天气状况和风速"
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "city": {
                    "type": "string",
                    "description": "城市名称"
                }
            },
            "required": ["city"]
        }
    
    async def execute(self, **kwargs) -> str:
        '''执行工具'''
        city = kwargs.get("city", "")
        
        if not city:
            return "错误：请提供城市名称"
        
        # 模拟天气数据
        weather_conditions = ["晴", "多云", "阴", "小雨", "中雨", "大雨", "雷阵雨", "雪"]
        weather_condition = random.choice(weather_conditions)
        
        # 根据季节和天气条件生成合理的温度范围
        current_month = datetime.now().month
        if current_month in [12, 1, 2]:  # 冬季
            base_temp = random.uniform(-10, 10)
        elif current_month in [3, 4, 5]:  # 春季
            base_temp = random.uniform(10, 25)
        elif current_month in [6, 7, 8]:  # 夏季
            base_temp = random.uniform(25, 38)
        else:  # 秋季
            base_temp = random.uniform(15, 28)
        
        # 根据天气条件调整温度
        if weather_condition in ["小雨", "中雨", "大雨", "雷阵雨"]:
            base_temp -= random.uniform(2, 8)
        elif weather_condition == "雪":
            base_temp = random.uniform(-15, 0)
        
        temperature = round(base_temp, 1)
        humidity = random.randint(30, 95)
        wind_speed = random.uniform(0.5, 15.0)
        wind_speed = round(wind_speed, 1)
        
        # 生成天气报告
        weather_report = f"""
{city}天气报告：
- 天气状况：{weather_condition}
- 温度：{temperature}°C
- 湿度：{humidity}%
- 风速：{wind_speed} m/s
- 更新时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
        
        return weather_report.strip()
