#!/usr/bin/env python3
"""
简单测试 - 验证核心架构
"""

import sys
import asyncio
from pathlib import Path

# 添加路径
sys.path.insert(0, str(Path(__file__).parent))

# 直接导入模块
import core.base as base
import core.registry as registry
import core.context as context
import core.provider as provider
import core.loop as loop


class EchoTool(base.Tool):
    """测试工具"""
    
    @property
    def name(self) -> str:
        return "echo"
    
    @property
    def description(self) -> str:
        return "回声工具"
    
    @property
    def parameters(self):
        return {
            "type": "object",
            "properties": {
                "message": {"type": "string"}
            },
            "required": ["message"]
        }
    
    async def execute(self, message: str) -> str:
        return f"Echo: {message}"


async def main():
    print("=" * 60)
    print("NanoGenesis 核心架构验证")
    print("=" * 60)
    
    # 1. 测试工具注册表
    print("\n[1/4] 测试工具注册表...")
    tool_registry = registry.ToolRegistry()
    echo_tool = EchoTool()
    tool_registry.register(echo_tool)
    
    assert "echo" in tool_registry
    print(f"  ✓ 工具注册成功: {echo_tool.name}")
    
    result = await tool_registry.execute("echo", {"message": "Hello"})
    assert result == "Echo: Hello"
    print(f"  ✓ 工具执行成功: {result}")
    
    # 2. 测试上下文构建器
    print("\n[2/4] 测试上下文构建器...")
    ctx_builder = context.SimpleContextBuilder()
    messages = await ctx_builder.build_messages("Test message")
    
    assert len(messages) == 2
    assert messages[0].role == base.MessageRole.SYSTEM
    assert messages[1].role == base.MessageRole.USER
    print(f"  ✓ 构建消息: {len(messages)} 条")
    print(f"  ✓ System prompt: {len(messages[0].content)} 字符")
    
    # 3. 测试 Mock Provider
    print("\n[3/4] 测试 LLM Provider...")
    mock_provider = provider.MockLLMProvider()
    response = await mock_provider.chat(
        messages=[{"role": "user", "content": "Hello"}]
    )
    
    assert response.content.startswith("Mock response")
    assert response.usage['total_tokens'] == 150
    print(f"  ✓ LLM 响应: {response.content}")
    print(f"  ✓ Token 使用: {response.usage['total_tokens']}")
    
    # 4. 测试 Agent 循环
    print("\n[4/4] 测试 Agent 循环...")
    agent_loop = loop.AgentLoop(
        tools=tool_registry,
        context=ctx_builder,
        provider=mock_provider,
        max_iterations=5
    )
    
    final_response, metrics = await agent_loop.run("Test input")
    
    assert metrics.success
    assert metrics.tokens > 0
    print(f"  ✓ Agent 响应: {final_response}")
    print(f"  ✓ 迭代次数: {metrics.iterations}")
    print(f"  ✓ Token 使用: {metrics.tokens}")
    print(f"  ✓ 耗时: {metrics.time:.3f}s")
    
    # 总结
    print("\n" + "=" * 60)
    print("🎉 所有测试通过！")
    print("=" * 60)
    
    print("\n✅ 核心组件状态:")
    print("  • ToolRegistry - 工具注册表运行正常")
    print("  • SimpleContextBuilder - 上下文构建器运行正常")
    print("  • MockLLMProvider - LLM 提供商运行正常")
    print("  • AgentLoop - Agent 循环运行正常")
    
    print("\n🏗️  架构特点:")
    print("  • 低耦合 - 组件独立，接口清晰")
    print("  • 高内聚 - 职责单一，易于理解")
    print("  • 易扩展 - 通过注册机制添加功能")
    print("  • 可测试 - 每个组件都可独立测试")
    
    print("\n📊 代码统计:")
    print(f"  • base.py: ~150 行 (基础类和接口)")
    print(f"  • registry.py: ~60 行 (工具注册表)")
    print(f"  • context.py: ~100 行 (上下文构建)")
    print(f"  • provider.py: ~120 行 (LLM 提供商)")
    print(f"  • loop.py: ~100 行 (Agent 循环)")
    print(f"  • 总计: ~530 行核心代码")
    
    print("\n🚀 下一步:")
    print("  1. 添加基础工具 (文件、Shell、Web)")
    print("  2. 实现诊断工具")
    print("  3. 添加策略管理")
    print("  4. 实现自优化机制")
    
    return 0


if __name__ == "__main__":
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code)
    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
