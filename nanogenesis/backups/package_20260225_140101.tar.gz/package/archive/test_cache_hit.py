"""测试缓存命中"""
import subprocess
import json
import os
from intelligence.protocol_encoder import ProtocolEncoder
from intelligence.user_persona import UserPersonaLearner
from intelligence.polyhedron_prompt import PolyhedronPromptBuilder

def call_api(api_key, system_prompt, user_message):
    data = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message}
        ],
        "max_tokens": 500
    }
    
    cmd = ['curl', '-X', 'POST', 'https://api.deepseek.com/v1/chat/completions',
           '-H', f'Authorization: Bearer {api_key}',
           '-H', 'Content-Type: application/json',
           '-d', json.dumps(data)]
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout)

api_key = os.getenv('DEEPSEEK_API_KEY')
if not api_key:
    raise RuntimeError("请先设置环境变量 DEEPSEEK_API_KEY")

encoder = ProtocolEncoder()
learner = UserPersonaLearner()
builder = PolyhedronPromptBuilder(encoder=encoder)

# 相同的 system prompt
user_persona = learner.generate_persona_summary()
system_prompt = builder.build_system_prompt(
    user_persona,
    {'budget': 0, 'environment': 'Linux', 'preferences': '本地化'},
    include_polyhedron=True
)

# 不同的问题
questions = [
    "Python 模块导入错误怎么办？",
    "Git 合并冲突如何解决？"
]

print("="*60)
print("测试缓存命中")
print("="*60)

for i, q in enumerate(questions, 1):
    print(f"\n第 {i} 次调用: {q}")
    
    encoded = encoder.encode({'problem': q})
    user_message = f"编码上下文：{encoded}\n请按多面体坍缩框架思考，给出最优解。"
    
    result = call_api(api_key, system_prompt, user_message)
    usage = result['usage']
    
    print(f"  输入: {usage['prompt_tokens']}")
    print(f"  缓存命中: {usage.get('prompt_cache_hit_tokens', 0)}")
    print(f"  缓存未命中: {usage.get('prompt_cache_miss_tokens', 0)}")
    
    if i == 1:
        cache_hit_rate = 0
    else:
        total_prompt = usage['prompt_tokens']
        cache_hit = usage.get('prompt_cache_hit_tokens', 0)
        cache_hit_rate = (cache_hit / total_prompt * 100) if total_prompt > 0 else 0
    
    print(f"  缓存命中率: {cache_hit_rate:.1f}%")

print("\n✅ 缓存测试完成")
