from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional

class MemoryStore(ABC):
    """Abstract Base Class for Memory Stores"""
    
    @abstractmethod
    async def add(self, content: str, metadata: Dict[str, Any] = None) -> None:
        """Add new memory item"""
        pass
        
    @abstractmethod
    async def search(self, query: str, limit: int = 5, **kwargs) -> List[Dict[str, Any]]:
        """Search memory"""
        pass
        
class SessionStore(ABC):
    """Abstract Base Class for Session Management"""
    
    @abstractmethod
    async def save_turn(self, user_input: str, assistant_response: str, tools_used: List[str] = None) -> None:
        """Save a conversation turn"""
        pass
        
    @abstractmethod
    async def get_recent_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Get recent conversation history"""
        pass
        
    @abstractmethod
    async def get_full_history(self) -> List[Dict[str, Any]]:
        """Get full conversation history"""
        pass
