#!/usr/bin/env python3
"""
测试自动工具生成 - 类似 OpenClaw 的工作流
"""

import asyncio
import os
from intelligence.tool_generator import ToolGenerator


async def test():
    print("="*60)
    print("测试：Genesis 自动生成工具（类似 OpenClaw）")
    print("="*60)
    
    api_key = os.getenv('DEEPSEEK_API_KEY')
    if not api_key:
        raise RuntimeError("请先设置环境变量 DEEPSEEK_API_KEY")

    generator = ToolGenerator(api_key=api_key)
    
    # 测试场景：用户要打开 Chrome，但没有这个工具
    print("\n场景：用户说'打开我的chrome浏览器'")
    print("当前没有 open_chrome 工具，需要自动生成\n")
    
    tool_description = """
    创建一个打开 Chrome 浏览器的工具。
    
    功能：
    - 在 Linux 系统上打开 Chrome 浏览器
    - 支持指定 URL（可选）
    - 使用 subprocess 执行系统命令
    """
    
    print("步骤 1: 生成工具代码...")
    tool_file = generator.generate_tool(tool_description, "open_chrome")
    
    if tool_file:
        print(f"✓ 工具代码已生成: {tool_file}\n")
        
        # 显示生成的代码
        with open(tool_file, 'r', encoding='utf-8') as f:
            code = f.read()
        print("生成的代码:")
        print("-" * 60)
        print(code)
        print("-" * 60)
        
        # 步骤 2: 加载工具
        print("\n步骤 2: 加载工具...")
        try:
            tool = generator.load_tool(tool_file)
            print(f"✓ 工具加载成功: {tool.name}")
            print(f"  描述: {tool.description}")
            print(f"  参数: {tool.parameters}")
            
            # 步骤 3: 测试执行
            print("\n步骤 3: 测试执行...")
            result = await tool.execute()
            print(f"✓ 执行结果:\n{result}")
            
            print("\n" + "="*60)
            print("✅ 工具自动生成测试成功！")
            print("="*60)
            print("\nGenesis 可以像 OpenClaw 一样：")
            print("  1. 检测到缺少工具")
            print("  2. 自动生成工具代码")
            print("  3. 加载并注册工具")
            print("  4. 立即使用新工具")
            
        except Exception as e:
            print(f"✗ 工具加载/执行失败: {e}")
            import traceback
            traceback.print_exc()
    else:
        print("✗ 工具生成失败")


if __name__ == '__main__':
    asyncio.run(test())
