#!/usr/bin/env python3
"""
Genesis 交互式对话界面
"""

import asyncio
import sys
import os
from datetime import datetime
from agent_with_polyhedron import NanoGenesisWithPolyhedron
from core.conversation import ConversationManager


class GenesisChat:
    """Genesis 对话界面"""
    
    def __init__(self, api_key: str):
        self.verbose = str(os.getenv('GENESIS_VERBOSE', '')).lower() in {"1", "true", "yes", "y"}
        self.agent = NanoGenesisWithPolyhedron(
            api_key=api_key,
            model="deepseek-chat",
            user_persona_path="./data/user_persona.json"
        )
        self.conv_manager = ConversationManager()
        self.session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        print("="*60)
        print("Genesis v0.2.0 - 交互式对话")
        print("="*60)
        print(f"会话 ID: {self.session_id}")
        print("\n命令:")
        print("  /help    - 显示帮助")
        print("  /history - 查看对话历史")
        print("  /stats   - 查看统计信息")
        print("  /clear   - 清空对话")
        print("  /exit    - 退出")
        print("\n开始对话吧！\n")
    
    async def chat(self):
        """开始对话"""
        
        while True:
            try:
                # 获取用户输入
                user_input = input("你: ").strip()
                
                if not user_input:
                    continue
                
                # 处理命令
                if user_input.startswith('/'):
                    if await self._handle_command(user_input):
                        continue
                    else:
                        break
                
                # 添加用户消息
                self.conv_manager.add_message(self.session_id, "user", user_input)
                
                # 显示思考中
                print("\nGenesis: [思考中...]", end='\r')
                
                # 处理请求
                result = await self.agent.process(
                    user_input=user_input,
                    intent_type="problem"  # 可以根据内容自动判断
                )
                
                # 清除"思考中"
                print(" " * 50, end='\r')
                
                # 显示响应
                response = result['response']
                print(f"Genesis: {response}\n")
                
                # 添加 AI 响应
                self.conv_manager.add_message(self.session_id, "assistant", response)
                
                # 显示性能信息（可选）
                if self.verbose and result.get('use_polyhedron'):
                    print(f"[使用多面体框架 | 复杂度: {result['complexity']}]")
                
            except KeyboardInterrupt:
                print("\n\n再见！")
                break
            except Exception as e:
                print(f"\n错误: {e}\n")
    
    async def _handle_command(self, command: str) -> bool:
        """
        处理命令
        
        Returns:
            True 继续对话，False 退出
        """
        cmd = command.lower()
        
        if cmd == '/exit' or cmd == '/quit':
            print("\n再见！")
            return False
        
        elif cmd == '/help':
            print("\n命令列表:")
            print("  /help    - 显示此帮助")
            print("  /history - 查看对话历史")
            print("  /stats   - 查看统计信息")
            print("  /clear   - 清空当前对话")
            print("  /exit    - 退出程序\n")
        
        elif cmd == '/history':
            messages = self.conv_manager.get_messages(self.session_id)
            print(f"\n对话历史 (共 {len(messages)} 条):")
            print("-" * 60)
            for msg in messages:
                role_name = "你" if msg.role == "user" else "Genesis"
                content = msg.content[:100] + "..." if len(msg.content) > 100 else msg.content
                print(f"[{role_name}] {content}")
            print("-" * 60 + "\n")
        
        elif cmd == '/stats':
            summary = self.conv_manager.get_summary(self.session_id)
            stats = self.agent.get_statistics()
            
            print("\n统计信息:")
            print("-" * 60)
            print(f"对话轮次: {summary.get('total_messages', 0)}")
            print(f"用户消息: {summary.get('user_messages', 0)}")
            print(f"AI 响应: {summary.get('assistant_messages', 0)}")
            print(f"对话时长: {summary.get('duration', '0分钟')}")
            print(f"\n用户画像:")
            print(f"  交互次数: {stats['user_interactions']}")
            print(f"  置信度: {stats['user_confidence']:.2f}")
            print(f"  专业领域: {', '.join(stats['user_expertise']) if stats['user_expertise'] else '通用'}")
            print("-" * 60 + "\n")
        
        elif cmd == '/clear':
            self.conv_manager.clear_conversation(self.session_id)
            self.session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            print(f"\n对话已清空，新会话 ID: {self.session_id}\n")
        
        else:
            print(f"\n未知命令: {command}")
            print("输入 /help 查看可用命令\n")
        
        return True


async def main():
    """主函数"""
    
    # 从环境变量或参数获取 API key
    import os
    
    api_key = os.getenv('DEEPSEEK_API_KEY')
    
    if not api_key:
        # 从命令行参数获取
        if len(sys.argv) > 1:
            api_key = sys.argv[1]
        else:
            print("请提供 API key:")
            print("  方式1: export DEEPSEEK_API_KEY='your-key'")
            print("  方式2: python3 chat.py your-key")
            sys.exit(1)
    
    # 创建对话
    chat = GenesisChat(api_key)
    await chat.chat()


if __name__ == '__main__':
    asyncio.run(main())
