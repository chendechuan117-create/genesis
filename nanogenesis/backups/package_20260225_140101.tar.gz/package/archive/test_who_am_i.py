#!/usr/bin/env python3
"""
测试 Genesis 处理 "我是谁" 问题
"""

import asyncio
import os
from agent_with_polyhedron import NanoGenesisWithPolyhedron


async def test():
    print("="*60)
    print("测试：我是谁")
    print("="*60)
    
    api_key = os.getenv('DEEPSEEK_API_KEY')
    if not api_key:
        raise RuntimeError("请先设置环境变量 DEEPSEEK_API_KEY")

    # 创建 agent
    agent = NanoGenesisWithPolyhedron(api_key=api_key)
    
    # 测试问题
    print("\n用户: 我是谁\n")
    
    try:
        result = await agent.process(
            user_input="我是谁",
            intent_type="question"
        )
        
        print("Genesis:")
        print(result['response'])
        
        print("\n性能:")
        print(f"  迭代: {result['metrics'].iterations}")
        print(f"  耗时: {result['metrics'].total_time:.2f}s")
        
    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    asyncio.run(test())
