#!/usr/bin/env python3
"""
测试自适应学习系统
"""

import asyncio
from intelligence.adaptive_learner import AdaptiveLearner


async def test():
    print("="*60)
    print("测试自适应学习系统")
    print("="*60)
    
    learner = AdaptiveLearner("./data/test_adaptive.json")
    
    # 模拟一系列交互
    interactions = [
        # 用户偏好简洁
        ("帮我看看", "这是权限问题，运行 chmod +x file 即可", "好"),
        ("再试试", "已修复", "谢谢"),
        
        # 用户使用技术词汇
        ("docker 启动失败", "检查 docker.service 状态", "ok"),
        ("查看 logs", "docker logs container_name", "明白了"),
        
        # 用户使用 emoji
        ("搞定了吗？", "已完成 ✅", "👍"),
    ]
    
    print("\n模拟交互...")
    for i, (user_msg, ai_resp, user_react) in enumerate(interactions, 1):
        print(f"\n交互 {i}:")
        print(f"  用户: {user_msg}")
        print(f"  AI: {ai_resp}")
        print(f"  反应: {user_react}")
        
        learner.observe_interaction(user_msg, ai_resp, user_react)
    
    # 显示学习结果
    print("\n" + "="*60)
    print("学习结果")
    print("="*60)
    
    pattern = learner.pattern
    print(f"\n偏好简洁: {pattern.prefers_concise:.2f} (0=详细, 1=简洁)")
    print(f"偏好技术: {pattern.prefers_technical:.2f} (0=通俗, 1=技术)")
    print(f"使用 emoji: {pattern.uses_emoji:.2f}")
    print(f"平均消息长度: {pattern.message_length_avg:.0f} 字符")
    print(f"正式程度: {pattern.formality:.2f} (0=随意, 1=正式)")
    print(f"置信度: {pattern.confidence:.2f}")
    print(f"总交互: {pattern.total_interactions} 次")
    print(f"积极信号: {pattern.positive_signals}")
    print(f"消极信号: {pattern.negative_signals}")
    
    # 生成自适应 prompt
    print("\n" + "="*60)
    print("自适应 System Prompt")
    print("="*60)
    prompt = learner.generate_adaptive_prompt()
    print(prompt)
    
    # 获取回复指导
    print("\n" + "="*60)
    print("回复指导原则")
    print("="*60)
    guidelines = learner.get_response_guidelines()
    for key, value in guidelines.items():
        print(f"  {key}: {value}")
    
    print("\n" + "="*60)
    print("✅ 自适应学习系统工作正常！")
    print("="*60)
    print("\n特点：")
    print("  1. 从每次交互中学习用户风格")
    print("  2. 动态调整 system prompt")
    print("  3. 根据反馈持续优化")
    print("  4. 不依赖固定配置文件")


if __name__ == '__main__':
    asyncio.run(test())
