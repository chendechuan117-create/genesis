"""
简化版真实 API 测试 - 直接使用 requests
"""

import os
import requests
import json
from intelligence.protocol_encoder import ProtocolEncoder
from intelligence.context_filter import LocalLLMContextFilter, MockLocalLLM
from intelligence.user_persona import UserPersonaLearner
from intelligence.polyhedron_prompt import PolyhedronPromptBuilder, ComplexityEstimator


def call_deepseek_api(api_key: str, system_prompt: str, user_message: str):
    """直接调用 DeepSeek API"""
    
    url = "https://api.deepseek.com/v1/chat/completions"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    data = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message}
        ],
        "temperature": 0.7
    }
    
    response = requests.post(url, headers=headers, json=data)
    
    if response.status_code == 200:
        result = response.json()
        return result
    else:
        raise Exception(f"API 调用失败: {response.status_code} - {response.text}")


def main():
    """测试流程"""
    
    api_key = os.getenv('DEEPSEEK_API_KEY')
    if not api_key:
        raise RuntimeError("请先设置环境变量 DEEPSEEK_API_KEY")
    
    print("="*60)
    print("真实 API 测试 - 多面体框架")
    print("="*60)
    
    # 初始化组件
    encoder = ProtocolEncoder()
    filter = LocalLLMContextFilter(local_llm=MockLocalLLM(), max_files=5)
    learner = UserPersonaLearner()
    builder = PolyhedronPromptBuilder(encoder=encoder)
    estimator = ComplexityEstimator()
    
    # 用户输入
    user_input = "Docker 容器启动失败，提示 permission denied，我该怎么解决？"
    
    # 可用上下文
    available_contexts = {
        'docker_perm': 'Docker 权限问题：用户不在 docker 组，运行 sudo usermod -aG docker $USER',
        'linux_perm': 'Linux 权限：chmod 修改权限，chown 修改所有者',
        'docker_compose': 'Docker Compose 配置：user: "${UID}:${GID}"',
    }
    
    print(f"\n用户问题: {user_input}\n")
    
    # 步骤 1: 筛选上下文
    print("步骤 1: 筛选上下文")
    selected = filter.filter_context(user_input, available_contexts)
    print(f"  筛选: {len(available_contexts)} → {len(selected)} 个")
    
    # 步骤 2: 协议编码
    print("\n步骤 2: 协议编码")
    encoded = encoder.encode({
        'problem': user_input,
        'env_info': {'os': 'linux'},
        'diagnosis': 'User permission issue',
        'strategy': 'Add user to docker group',
        'user_pref': 'config'
    })
    print(f"  编码: {encoded[:80]}...")
    
    # 步骤 3: 估算复杂度
    print("\n步骤 3: 估算复杂度")
    complexity = estimator.estimate(user_input)
    use_polyhedron = builder.should_use_polyhedron("problem", 0.7, complexity)
    print(f"  复杂度: {complexity}")
    print(f"  使用多面体: {'是' if use_polyhedron else '否'}")
    
    # 步骤 4: 构建 system prompt
    print("\n步骤 4: 构建 System Prompt")
    user_persona = learner.generate_persona_summary()
    system_prompt = builder.build_system_prompt(
        user_persona,
        {'budget': 0, 'environment': 'Linux', 'preferences': '本地化'},
        include_polyhedron=use_polyhedron
    )
    print(f"  长度: {len(system_prompt)} 字符")
    
    # 步骤 5: 构建 user message
    print("\n步骤 5: 构建 User Message")
    user_message_parts = [f"编码上下文：{encoded}"]
    if selected:
        user_message_parts.append("\n相关记忆：")
        for key, content in list(selected.items())[:2]:
            user_message_parts.append(f"\n### {key}\n{content}")
    if use_polyhedron:
        user_message_parts.append("\n请按多面体坍缩框架思考，给出最优解。")
    
    user_message = '\n'.join(user_message_parts)
    print(f"  长度: {len(user_message)} 字符")
    
    # 步骤 6: 调用 API
    print("\n步骤 6: 调用 DeepSeek API")
    print("  请求中...")
    
    try:
        result = call_deepseek_api(api_key, system_prompt, user_message)
        
        # 解析结果
        response_text = result['choices'][0]['message']['content']
        usage = result['usage']
        
        print("\n" + "="*60)
        print("AI 响应:")
        print("="*60)
        print(response_text)
        
        print("\n" + "="*60)
        print("Token 使用:")
        print("="*60)
        print(f"  输入: {usage['prompt_tokens']}")
        print(f"  输出: {usage['completion_tokens']}")
        print(f"  总计: {usage['total_tokens']}")
        
        if 'prompt_cache_hit_tokens' in usage:
            print(f"  缓存命中: {usage['prompt_cache_hit_tokens']}")
            print(f"  缓存未命中: {usage['prompt_cache_miss_tokens']}")
        
        print("\n✅ 测试成功！")
        
    except Exception as e:
        print(f"\n❌ 测试失败: {e}")


if __name__ == '__main__':
    main()
