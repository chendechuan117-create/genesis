"""
Genesis Providers Directory

Importing this package automatically registers the built-in providers
into the global provider_registry.
"""

from .cloud_providers import *
