"""
NanoGenesis with Polyhedron - 融入多面体坍缩框架的完整 Agent

集成了：
1. 本地 LLM 上下文筛选器 - 决定发送哪些文件
2. 协议编码器 - 压缩传输，不丢失信息
3. 用户人格侧写学习器 - 向量 0
4. 多面体 System Prompt 构建器 - 动态启用
"""

from typing import Dict, List, Optional
import asyncio
import logging

from core.base import Tool, PerformanceMetrics, Message, MessageRole
from core.registry import ToolRegistry
from core.loop import AgentLoop
from core.context import SimpleContextBuilder
from core.provider import LiteLLMProvider, MockLLMProvider

from intelligence.diagnostic_tool import DiagnosticTool
from intelligence.strategy_tool import StrategySearchTool
from intelligence.protocol_encoder import ProtocolEncoder
from intelligence.context_filter import LocalLLMContextFilter, MockLocalLLM
from intelligence.user_persona import UserPersonaLearner
from intelligence.polyhedron_prompt import PolyhedronPromptBuilder, ComplexityEstimator
from intelligence.adaptive_learner import AdaptiveLearner

from tools.file_tools import ReadFileTool, WriteFileTool, AppendFileTool, ListDirectoryTool
from tools.shell_tool import ShellTool


logger = logging.getLogger(__name__)


class NanoGenesisWithPolyhedron:
    """融入多面体坍缩框架的 NanoGenesis"""
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model: str = "deepseek-chat",
        max_iterations: int = 15,
        user_persona_path: Optional[str] = None,
        local_llm = None
    ):
        """
        初始化
        
        Args:
            api_key: API 密钥
            base_url: API 基础 URL
            model: 模型名称
            max_iterations: 最大迭代次数
            user_persona_path: 用户画像存储路径
            local_llm: 本地 LLM 实例（用于上下文筛选）
        """
        # 核心组件
        self.tools = ToolRegistry()
        self.context = SimpleContextBuilder()
        
        # Provider
        if api_key or base_url:
            try:
                self.provider = LiteLLMProvider(
                    api_key=api_key,
                    base_url=base_url,
                    default_model=model
                )
            except ImportError:
                # LiteLLM 未安装，使用 curl 方案
                from core.curl_provider import CurlProvider
                self.provider = CurlProvider(
                    api_key=api_key,
                    base_url=base_url or "https://api.deepseek.com",
                    default_model=model
                )
        else:
            self.provider = MockLLMProvider()
        
        # Agent 循环
        self.loop = AgentLoop(
            tools=self.tools,
            context=self.context,
            provider=self.provider,
            max_iterations=max_iterations
        )
        
        # === 新增组件 ===
        
        # 协议编码器
        self.encoder = ProtocolEncoder()
        
        # 本地 LLM 上下文筛选器
        self.context_filter = LocalLLMContextFilter(
            local_llm=local_llm or MockLocalLLM(),
            max_files=5
        )

        self._openclaw_memory_cache = None
        
        # 用户人格侧写学习器
        # 自适应学习器（核心：从交互中学习）
        self.adaptive_learner = AdaptiveLearner()

        self.persona_learner = UserPersonaLearner(
            storage_path=user_persona_path or './data/user_persona.json'
        )
        
        # 多面体 Prompt 构建器
        self.polyhedron_builder = PolyhedronPromptBuilder(encoder=self.encoder)
        
        # 复杂度估算器
        self.complexity_estimator = ComplexityEstimator()
        
        # 注册所有工具
        self._register_tools()
    
    def _register_tools(self):
        """注册所有工具"""
        # 文件工具
        self.tools.register(ReadFileTool())
        self.tools.register(WriteFileTool())
        self.tools.register(AppendFileTool())
        self.tools.register(ListDirectoryTool())
        
        # 系统工具
        self.tools.register(ShellTool())
        
        # 智能工具
        self.tools.register(DiagnosticTool())
        self.tools.register(StrategySearchTool())
    
    async def process(
        self,
        user_input: str,
        intent_type: str = "problem",
        available_contexts: Optional[Dict[str, str]] = None,
        constraints: Optional[Dict] = None
    ) -> Dict:
        """
        处理用户输入（融入多面体框架）
        
        Args:
            user_input: 用户输入
            intent_type: 意图类型 (problem/task/query)
            constraints: 约束条件
        
        Returns:
            处理结果
        """
        
        # 自动加载 OpenClaw 记忆（如果没有提供）
        if available_contexts is None:
            if self._openclaw_memory_cache is not None:
                available_contexts = self._openclaw_memory_cache
            else:
                from pathlib import Path
                openclaw_path = Path('./data/openclaw_memory')
                if openclaw_path.exists():
                    try:
                        from integrations.openclaw_memory import OpenClawMemoryLoader
                        loader = OpenClawMemoryLoader(str(openclaw_path))
                        available_contexts = loader.load_all_memories()
                    except Exception as e:
                        logger.debug(f"加载 OpenClaw 记忆失败: {e}")
                        available_contexts = {}
                else:
                    available_contexts = {}

                self._openclaw_memory_cache = available_contexts
        
        # === 阶段 1: 本地处理 ===
        
        # 1.1 诊断（如果是问题类型）
        diagnosis = None
        if intent_type == "problem":
            diagnosis = await self._diagnose(user_input)
        
        # 1.2 策略搜索
        strategies = await self._search_strategies(user_input)
        
        # 1.3 本地 LLM 筛选上下文
        selected_contexts = {}
        if available_contexts:
            selected_contexts = self.context_filter.filter_context(
                user_input,
                available_contexts
            )
        
        # === 阶段 2: 估算复杂度，决定是否使用多面体 ===
        
        complexity = self.complexity_estimator.estimate(user_input, diagnosis)
        confidence = diagnosis.get('confidence', 0.5) if diagnosis else 0.5
        use_polyhedron = complexity == 'high' and any(k in user_input for k in [
            '如何', '怎么', '为什么', '解决', '优化', '设计', '架构', '方案'
        ])
        
        # === 阶段 3: 协议编码 ===
        
        encoded_context = self.encoder.encode({
            'problem': user_input,
            'env_info': diagnosis.get('env_info', {}) if diagnosis else {},
            'diagnosis': diagnosis.get('root_cause', '') if diagnosis else '',
            'strategy': (strategies[0].get('solution', '') if isinstance(strategies[0], dict) else '') if strategies else '',
            'user_pref': self.persona_learner.persona.preferred_solution_type
        })
        
        # === 阶段 4: 构建 System Prompt ===
        
        user_persona = self.persona_learner.generate_persona_summary()
        constraints = constraints or {
            'budget': 0,
            'environment': 'Linux',
            'preferences': '本地化、开源'
        }
        
        # 使用自适应学习生成的 prompt（根据用户偏好动态调整）
        system_prompt = self.adaptive_learner.generate_adaptive_prompt()
        
        # 添加用户记忆（如果有）
        if selected_contexts:
            memory_text = "\n\n你记得这些：\n"
            for key, content in list(selected_contexts.items())[:3]:  # 只显示前3个最相关的
                memory_text += f"- {key}: {content[:100]}...\n"
            system_prompt += memory_text
        
        # === 阶段 5: 构建 User Message ===
        
        user_message_parts = [user_input]
        
        # 添加筛选后的上下文
        if selected_contexts:
            user_message_parts.append("相关记忆：")
            for key, content in selected_contexts.items():
                user_message_parts.append(f"### {key}\n{content}")
        
        if use_polyhedron:
            user_message_parts.append("请按多面体坍缩框架思考，给出最优解。")
        
        user_message = '\n\n'.join(user_message_parts)
        
        # === 阶段 6: 执行 Agent ===
        
        # 设置自定义 system prompt
        self.context.system_prompt = system_prompt
        
        # 运行 Agent
        response, metrics = await self.loop.run(user_message)

        self.context.add_to_history(Message(role=MessageRole.USER, content=user_input))
        self.context.add_to_history(Message(role=MessageRole.ASSISTANT, content=response))
        
        # === 阶段 7: 学习优化 ===
        
        # 自适应学习：观察这次交互
        self.adaptive_learner.observe_interaction(
            user_message=user_input,
            assistant_response=response,
            user_reaction=None  # 下次交互时会更新
        )
        
        # 记录交互，学习用户人格
        self.persona_learner.learn_from_interaction({
            'problem': user_input,
            'solution': response,
            'tools_used': [call['function']['name'] for call in metrics.tool_calls] if metrics.tool_calls else [],
            'success': True,  # 简化处理，实际应该根据用户反馈
        })
        
        return {
            'response': response,
            'metrics': metrics,
            'complexity': complexity,
            'use_polyhedron': use_polyhedron,
            'encoded_context': encoded_context,
            'selected_contexts': list(selected_contexts.keys()) if selected_contexts else [],
            'diagnosis': diagnosis,
            'strategies': strategies,
        }
    
    async def _diagnose(self, user_input: str) -> Optional[Dict]:
        """诊断问题"""
        try:
            diagnostic_tool = DiagnosticTool()
            # 自动检测领域
            domain = self._detect_domain(user_input)
            result = await diagnostic_tool.execute(problem=user_input, domain=domain)
            
            # 解析结果
            import json
            return json.loads(result)
        except Exception as e:
            # 诊断失败不影响基本功能
            logger.debug(f"诊断失败 (非致命): {e}")
            return None
    
    def _detect_domain(self, text: str) -> str:
        """检测问题领域"""
        text_lower = text.lower()
        if any(k in text_lower for k in ['docker', 'container', '容器']):
            return 'docker'
        elif any(k in text_lower for k in ['python', 'pip', 'virtualenv']):
            return 'python'
        elif any(k in text_lower for k in ['git', 'commit', 'branch']):
            return 'git'
        elif any(k in text_lower for k in ['network', 'port', '网络', '端口']):
            return 'network'
        elif any(k in text_lower for k in ['database', 'sql', '数据库']):
            return 'database'
        else:
            return 'linux'
    
    async def _search_strategies(self, user_input: str) -> List[Dict]:
        """搜索策略"""
        try:
            strategy_tool = StrategySearchTool()
            result = await strategy_tool.execute(problem=user_input)
            
            # 解析结果
            import json
            data = json.loads(result)
            return data.get('strategies', [])
        except Exception as e:
            # 策略文件不存在是正常的，不显示错误
            return []
    
    def get_user_persona_summary(self) -> str:
        """获取用户人格侧写摘要"""
        return self.persona_learner.generate_persona_summary()
    
    def get_statistics(self) -> Dict:
        """获取统计信息"""
        return {
            'tools_registered': len(self.tools),
            'user_interactions': self.persona_learner.persona.interaction_count,
            'user_confidence': self.persona_learner.persona.confidence,
            'user_expertise': self.persona_learner.persona.expertise,
        }


# 示例用法
async def main():
    """示例：完整流程演示"""
    
    print("="*60)
    print("NanoGenesis with Polyhedron - 完整流程演示")
    print("="*60)
    
    # 创建 Agent
    agent = NanoGenesisWithPolyhedron()
    
    # 模拟可用的上下文（记忆文件）
    available_contexts = {
        'docker_issue_1': 'Docker 容器权限问题：用户不在 docker 组...',
        'docker_issue_2': 'Docker 网络配置问题...',
        'python_error_1': 'Python 模块导入错误...',
        'linux_perm_1': 'Linux 文件权限问题...',
        'git_conflict_1': 'Git 合并冲突...',
        'database_query_1': 'SQL 查询优化...',
        'web_api_1': 'REST API 开发...',
        'ci_cd_1': 'CI/CD 流水线配置...',
    }
    
    # 测试用例
    test_cases = [
        {
            'input': 'Docker 容器启动失败，提示 permission denied',
            'intent': 'problem',
            'description': '复杂问题 - 应该使用多面体'
        },
        {
            'input': '读取文件 /tmp/test.txt',
            'intent': 'task',
            'description': '简单任务 - 不应该使用多面体'
        },
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n{'='*60}")
        print(f"测试用例 {i}: {test_case['description']}")
        print(f"{'='*60}")
        print(f"输入: {test_case['input']}")
        
        result = await agent.process(
            test_case['input'],
            available_contexts=available_contexts,
            intent_type=test_case['intent']
        )
        
        print(f"\n复杂度: {result['complexity']}")
        print(f"使用多面体: {'是' if result['use_polyhedron'] else '否'}")
        print(f"编码上下文: {result['encoded_context'][:100]}...")
        print(f"筛选的上下文: {len(result['selected_contexts'])} 个")
        if result['selected_contexts']:
            for ctx in result['selected_contexts']:
                print(f"  - {ctx}")
        
        print(f"\n响应: {result['response']}")
        print(f"\nMetrics:")
        print(f"  - 迭代次数: {result['metrics'].iterations}")
        print(f"  - 工具调用: {len(result['metrics'].tool_calls) if result['metrics'].tool_calls else 0}")
    
    # 显示用户画像
    print(f"\n{'='*60}")
    print("用户人格侧写:")
    print(f"{'='*60}")
    print(agent.get_user_persona_summary())
    
    # 显示统计信息
    print(f"\n{'='*60}")
    print("系统统计:")
    print(f"{'='*60}")
    stats = agent.get_statistics()
    for key, value in stats.items():
        print(f"  - {key}: {value}")


if __name__ == '__main__':
    asyncio.run(main())
