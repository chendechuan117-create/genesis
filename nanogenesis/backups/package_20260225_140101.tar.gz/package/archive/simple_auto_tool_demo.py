#!/usr/bin/env python3
"""
简单演示：Genesis 自动生成工具（类似 OpenClaw）

演示完整工作流：
1. 用户请求
2. 检测缺少工具
3. 自动生成工具
4. 注册并使用
"""

import asyncio
import os
from intelligence.tool_generator import ToolGenerator
from core.registry import ToolRegistry


async def demo():
    print("="*60)
    print("Genesis 自动工具生成演示（类似 OpenClaw）")
    print("="*60)
    
    # 初始化
    api_key = os.getenv('DEEPSEEK_API_KEY')
    if not api_key:
        raise RuntimeError("请先设置环境变量 DEEPSEEK_API_KEY")
    generator = ToolGenerator(api_key=api_key)
    registry = ToolRegistry()
    
    # 场景：用户要打开 Chrome
    user_request = "打开我的chrome浏览器"
    
    print(f"\n用户请求: {user_request}")
    print(f"当前工具数: {len(registry)}")
    print(f"可用工具: {registry.list_tools()}")
    
    # 步骤 1: 检测需要什么工具
    needed_tool = "open_chrome"
    
    if needed_tool not in registry:
        print(f"\n🔧 检测到缺少工具: {needed_tool}")
        print("   开始自动生成...")
        
        # 步骤 2: 生成工具
        tool_description = f"""
        创建一个打开 Chrome 浏览器的工具。
        
        功能：
        - 在 Linux 系统上打开 Chrome 浏览器
        - 支持指定 URL（可选）
        - 使用 subprocess 执行系统命令
        - 后台运行，不阻塞
        """
        
        tool_file = generator.generate_tool(tool_description, needed_tool)
        
        if tool_file:
            print(f"   ✓ 工具代码已生成")
            
            # 步骤 3: 加载工具
            tool = generator.load_tool(tool_file)
            print(f"   ✓ 工具已加载: {tool.name}")
            
            # 步骤 4: 注册工具
            registry.register(tool)
            print(f"   ✓ 工具已注册")
            
            print(f"\n当前工具数: {len(registry)}")
            print(f"可用工具: {registry.list_tools()}")
            
            # 步骤 5: 使用工具
            print(f"\n执行工具: {needed_tool}")
            result = await registry.execute(needed_tool, {})
            print(f"✓ 执行结果: {result}")
            
            print("\n" + "="*60)
            print("✅ 完整工作流演示成功！")
            print("="*60)
            print("\nGenesis 实现了 OpenClaw 的核心能力：")
            print("  1. ✓ 检测缺少的工具")
            print("  2. ✓ 自动生成工具代码")
            print("  3. ✓ 动态加载工具")
            print("  4. ✓ 注册到工具注册表")
            print("  5. ✓ 立即使用新工具")
            print("\n🎉 Genesis 可以像 OpenClaw 一样工作了！")
        else:
            print("   ✗ 工具生成失败")
    else:
        print(f"\n✓ 工具 {needed_tool} 已存在")


if __name__ == '__main__':
    asyncio.run(demo())
