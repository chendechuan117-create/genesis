#!/usr/bin/env python3
"""
快速测试 - 单个命令
"""

import asyncio
import sys

# 简化版本，直接调用工具
from tools.file_tools import ListDirectoryTool, ReadFileTool, WriteFileTool
from tools.shell_tool import ShellTool


async def test_direct_tools():
    """直接测试工具"""
    
    print("="*60)
    print("Genesis 快速测试 - 直接调用工具")
    print("="*60)
    
    # 任务1: 列出当前目录
    print("\n任务1: 列出当前目录文件")
    print("-"*60)
    tool = ListDirectoryTool()
    result = await tool.execute(directory=".")
    print(result[:500])
    
    # 任务2: 创建文件
    print("\n任务2: 创建测试文件")
    print("-"*60)
    tool = WriteFileTool()
    result = await tool.execute(
        file_path="/tmp/genesis_test.txt",
        content="Genesis 测试\n这是自动创建的文件。"
    )
    print(result)
    
    # 任务3: 读取文件
    print("\n任务3: 读取刚创建的文件")
    print("-"*60)
    tool = ReadFileTool()
    result = await tool.execute(file_path="/tmp/genesis_test.txt")
    print(result)
    
    # 任务4: 执行 shell 命令
    print("\n任务4: 查看系统时间")
    print("-"*60)
    tool = ShellTool()
    result = await tool.execute(command="date")
    print(result)
    
    # 任务5: 查看系统信息
    print("\n任务5: 查看系统信息")
    print("-"*60)
    tool = ShellTool()
    result = await tool.execute(command="uname -a")
    print(result)
    
    print("\n" + "="*60)
    print("✅ 所有基础工具测试通过！")
    print("="*60)


if __name__ == '__main__':
    asyncio.run(test_direct_tools())
