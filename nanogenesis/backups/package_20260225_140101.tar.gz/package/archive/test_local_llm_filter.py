"""
测试本地 LLM 上下文筛选
"""

import subprocess
import json
from intelligence.context_filter import LocalLLMContextFilter


class OllamaLLM:
    """Ollama 本地 LLM"""
    
    def __init__(self, model="qwen2.5:3b"):
        self.model = model
    
    def generate(self, prompt: str, max_tokens: int = 100) -> str:
        """调用 Ollama 生成"""
        
        data = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "num_predict": max_tokens,
                "temperature": 0.3
            }
        }
        
        cmd = [
            'curl', '-s', '-X', 'POST',
            'http://localhost:11434/api/generate',
            '-H', 'Content-Type: application/json',
            '-d', json.dumps(data)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            response = json.loads(result.stdout)
            return response.get('response', '')
        else:
            raise Exception(f"Ollama 调用失败: {result.stderr}")


def main():
    print("="*60)
    print("本地 LLM 上下文筛选测试")
    print("="*60)
    
    # 创建 Ollama LLM
    print("\n初始化 Ollama (qwen2.5:3b)...")
    ollama = OllamaLLM(model="qwen2.5:3b")
    
    # 创建筛选器
    filter = LocalLLMContextFilter(local_llm=ollama, max_files=5)
    
    # 测试数据
    user_input = "Docker 容器启动失败，提示 permission denied，我该怎么解决？"
    
    available_files = [
        '/memory/docker_issues.md',
        '/memory/python_errors.md',
        '/memory/git_conflicts.md',
        '/memory/docker_networking.md',
        '/memory/linux_permissions.md',
        '/memory/database_queries.md',
        '/memory/web_apis.md',
        '/memory/docker_compose.md',
        '/memory/kubernetes.md',
        '/memory/ci_cd.md',
    ]
    
    file_summaries = {
        '/memory/docker_issues.md': 'Docker 常见问题和解决方案，包括权限、网络、端口等',
        '/memory/python_errors.md': 'Python 错误处理和调试技巧',
        '/memory/git_conflicts.md': 'Git 合并冲突解决方法',
        '/memory/docker_networking.md': 'Docker 网络配置详解',
        '/memory/linux_permissions.md': 'Linux 文件和用户权限管理',
        '/memory/database_queries.md': 'SQL 查询优化和索引',
        '/memory/web_apis.md': 'REST API 开发最佳实践',
        '/memory/docker_compose.md': 'Docker Compose 配置示例',
        '/memory/kubernetes.md': 'Kubernetes 部署和管理',
        '/memory/ci_cd.md': 'CI/CD 流水线配置',
    }
    
    print(f"\n用户问题: {user_input}")
    print(f"\n可用文件: {len(available_files)} 个")
    
    # 测试本地 LLM 筛选
    print("\n使用本地 LLM 筛选...")
    try:
        selected = filter.filter_files(user_input, available_files, file_summaries)
        
        print(f"\n筛选结果: {len(selected)} 个文件")
        print("\n选中的文件:")
        for i, f in enumerate(selected, 1):
            print(f"  {i}. {f}")
            if f in file_summaries:
                print(f"     摘要: {file_summaries[f]}")
        
        print(f"\n减少: {len(available_files) - len(selected)} 个文件")
        print(f"减少比例: {(1 - len(selected)/len(available_files))*100:.1f}%")
        
        print("\n✅ 本地 LLM 筛选测试成功！")
        
    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        print("\n回退到规则筛选...")
        
        # 测试规则筛选
        filter_rule = LocalLLMContextFilter(local_llm=None, max_files=5)
        selected = filter_rule.filter_files(user_input, available_files, file_summaries)
        
        print(f"\n规则筛选结果: {len(selected)} 个文件")
        for i, f in enumerate(selected, 1):
            print(f"  {i}. {f}")
        
        print("\n✅ 规则筛选工作正常")


if __name__ == '__main__':
    main()
