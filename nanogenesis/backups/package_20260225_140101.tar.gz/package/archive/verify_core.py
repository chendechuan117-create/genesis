#!/usr/bin/env python3
"""
验证 NanoGenesis 核心功能
"""

import sys
import asyncio
from pathlib import Path

# 添加当前目录到 Python 路径
sys.path.insert(0, str(Path(__file__).parent))

from core.base import Tool, MessageRole
from core.registry import ToolRegistry
from core.context import SimpleContextBuilder
from core.provider import MockLLMProvider
from core.loop import AgentLoop
from agent import NanoGenesis


class EchoTool(Tool):
    """测试用的回声工具"""
    
    @property
    def name(self) -> str:
        return "echo"
    
    @property
    def description(self) -> str:
        return "回声工具，返回输入的内容"
    
    @property
    def parameters(self):
        return {
            "type": "object",
            "properties": {
                "message": {"type": "string", "description": "要回声的消息"}
            },
            "required": ["message"]
        }
    
    async def execute(self, message: str) -> str:
        return f"Echo: {message}"


async def test_tool_registry():
    """测试工具注册表"""
    print("=" * 60)
    print("测试 1: 工具注册表")
    print("=" * 60)
    
    registry = ToolRegistry()
    tool = EchoTool()
    
    # 注册工具
    registry.register(tool)
    print(f"✓ 注册工具: {tool.name}")
    
    # 检查工具
    assert "echo" in registry
    print(f"✓ 工具存在检查通过")
    
    # 获取定义
    definitions = registry.get_definitions()
    assert len(definitions) == 1
    print(f"✓ 工具定义: {definitions[0]['function']['name']}")
    
    # 执行工具
    result = await registry.execute("echo", {"message": "Hello"})
    assert result == "Echo: Hello"
    print(f"✓ 工具执行: {result}")
    
    print("\n✅ 工具注册表测试通过\n")


async def test_context_builder():
    """测试上下文构建器"""
    print("=" * 60)
    print("测试 2: 上下文构建器")
    print("=" * 60)
    
    builder = SimpleContextBuilder()
    
    # 构建消息
    messages = await builder.build_messages("Hello, NanoGenesis!")
    
    assert len(messages) == 2
    assert messages[0].role == MessageRole.SYSTEM
    assert messages[1].role == MessageRole.USER
    print(f"✓ 构建消息: {len(messages)} 条")
    print(f"  - System: {messages[0].content[:50]}...")
    print(f"  - User: {messages[1].content}")
    
    # 添加工具结果
    updated = builder.add_tool_result(
        messages,
        tool_call_id="123",
        tool_name="echo",
        result="Echo: test"
    )
    
    assert len(updated) == 3
    assert updated[2].role == MessageRole.TOOL
    print(f"✓ 添加工具结果: {updated[2].content}")
    
    print("\n✅ 上下文构建器测试通过\n")


async def test_agent_loop():
    """测试 Agent 循环"""
    print("=" * 60)
    print("测试 3: Agent 循环")
    print("=" * 60)
    
    tools = ToolRegistry()
    context = SimpleContextBuilder()
    provider = MockLLMProvider()
    loop = AgentLoop(tools, context, provider, max_iterations=5)
    
    # 运行循环
    response, metrics = await loop.run("Hello")
    
    assert metrics.success
    assert metrics.iterations >= 1
    assert metrics.tokens > 0
    
    print(f"✓ 响应: {response}")
    print(f"✓ 迭代次数: {metrics.iterations}")
    print(f"✓ Token 使用: {metrics.tokens}")
    print(f"✓ 耗时: {metrics.time:.3f}s")
    
    print("\n✅ Agent 循环测试通过\n")


async def test_nanogenesis():
    """测试 NanoGenesis 主类"""
    print("=" * 60)
    print("测试 4: NanoGenesis 主类")
    print("=" * 60)
    
    # 初始化
    agent = NanoGenesis()
    agent.provider = MockLLMProvider()
    
    print(f"✓ 初始化完成")
    
    # 处理问题
    result = await agent.process("Docker 容器启动失败")
    
    assert result['success']
    assert 'response' in result
    assert 'metrics' in result
    
    print(f"✓ 问题: Docker 容器启动失败")
    print(f"✓ 响应: {result['response']}")
    print(f"✓ Token: {result['metrics'].tokens}")
    
    # 多次交互
    for i in range(3):
        await agent.process(f"问题 {i+1}")
    
    # 统计
    stats = agent.get_stats()
    assert stats['total_interactions'] == 4
    
    print(f"\n✓ 统计信息:")
    print(f"  - 总交互: {stats['total_interactions']}")
    print(f"  - 平均 Token: {stats['avg_tokens']:.0f}")
    print(f"  - 成功率: {stats['success_rate']:.1%}")
    
    print("\n✅ NanoGenesis 主类测试通过\n")


async def main():
    """运行所有测试"""
    print("\n" + "=" * 60)
    print("NanoGenesis 核心功能验证")
    print("=" * 60 + "\n")
    
    try:
        await test_tool_registry()
        await test_context_builder()
        await test_agent_loop()
        await test_nanogenesis()
        
        print("=" * 60)
        print("🎉 所有测试通过！核心架构运行正常")
        print("=" * 60)
        
        print("\n核心组件状态:")
        print("  ✅ 工具注册表 - 统一接口，动态管理")
        print("  ✅ 上下文构建器 - system + user 分离，优化缓存")
        print("  ✅ Agent 循环 - ReAct 模式，推理→行动→观察")
        print("  ✅ NanoGenesis 主类 - 整合所有组件")
        
        print("\n架构特点:")
        print("  🏗️  低耦合 - 每个组件独立，通过接口通信")
        print("  🎯 高内聚 - 每个模块职责单一明确")
        print("  🔧 易扩展 - 新功能通过注册机制添加")
        print("  ✅ 可测试 - 所有组件都可独立测试")
        
        print("\n下一步:")
        print("  1. 添加基础工具（文件、Shell、Web）")
        print("  2. 实现智能诊断工具")
        print("  3. 添加策略管理")
        print("  4. 实现自优化机制")
        
        return 0
        
    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
