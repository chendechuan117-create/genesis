#!/usr/bin/env python3
"""
Genesis 交互式测试 - 真实用户体验

用自然语言下达命令，Genesis 自动完成
"""

import asyncio
import os
from agent_with_polyhedron import NanoGenesisWithPolyhedron
from intelligence.tool_generator import ToolGenerator


class InteractiveGenesis:
    """交互式 Genesis"""
    
    def __init__(self, api_key: str):
        self.agent = NanoGenesisWithPolyhedron(api_key=api_key)
        self.generator = ToolGenerator(api_key=api_key)
        self.session_count = 0
    
    async def execute_command(self, command: str):
        """执行用户命令"""
        self.session_count += 1
        
        print(f"\n{'='*60}")
        print(f"命令 #{self.session_count}: {command}")
        print(f"{'='*60}")
        
        try:
            # 处理命令
            result = await self.agent.process(
                user_input=command,
                intent_type="task"
            )
            
            print(f"\nGenesis 响应:")
            print("-" * 60)
            print(result['response'])
            print("-" * 60)
            
            # 显示性能信息
            metrics = result['metrics']
            print(f"\n性能: {metrics.iterations} 次迭代, {metrics.total_time:.2f}s")
            
            if result.get('use_polyhedron'):
                print(f"使用了多面体框架 (复杂度: {result['complexity']})")
            
            return True
            
        except Exception as e:
            print(f"\n❌ 执行失败: {e}")
            import traceback
            traceback.print_exc()
            return False


async def main():
    print("="*60)
    print("Genesis 交互式测试")
    print("="*60)
    print("\n模拟真实用户场景，用自然语言下达命令\n")
    
    api_key = os.getenv('DEEPSEEK_API_KEY')
    if not api_key:
        raise RuntimeError("请先设置环境变量 DEEPSEEK_API_KEY")

    genesis = InteractiveGenesis(api_key=api_key)
    
    # 预设的测试命令（模拟真实用户）
    commands = [
        "帮我查看当前目录下有哪些文件",
        "创建一个名为 test.txt 的文件，内容是 'Hello Genesis'",
        "读取刚才创建的 test.txt 文件内容",
        "查看系统当前时间",
        "列出 /tmp 目录下的所有文件"
    ]
    
    print("测试命令列表:")
    for i, cmd in enumerate(commands, 1):
        print(f"  {i}. {cmd}")
    
    print("\n开始执行...\n")
    
    # 执行所有命令
    results = []
    for cmd in commands:
        success = await genesis.execute_command(cmd)
        results.append((cmd, success))
        
        # 等待一下，避免太快
        await asyncio.sleep(1)
    
    # 总结
    print("\n" + "="*60)
    print("测试总结")
    print("="*60)
    
    success_count = sum(1 for _, success in results if success)
    print(f"\n总命令数: {len(results)}")
    print(f"成功: {success_count}")
    print(f"失败: {len(results) - success_count}")
    print(f"成功率: {success_count/len(results)*100:.1f}%")
    
    print("\n命令执行情况:")
    for cmd, success in results:
        status = "✓" if success else "✗"
        print(f"  {status} {cmd}")
    
    if success_count == len(results):
        print("\n🎉 所有命令执行成功！")
    
    print(f"\n当前工具数: {len(genesis.agent.tools)}")


if __name__ == '__main__':
    asyncio.run(main())
