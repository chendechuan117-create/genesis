#!/usr/bin/env python3
"""
Genesis 对话界面 - 集成 OpenClaw 记忆
"""

import asyncio
import sys
import os
from datetime import datetime
from pathlib import Path

from agent_with_polyhedron import NanoGenesisWithPolyhedron
from core.conversation import ConversationManager
from integrations.openclaw_memory import OpenClawMemoryLoader, convert_openclaw_to_genesis_context


class GenesisWithOpenClaw:
    """Genesis + OpenClaw 记忆"""
    
    def __init__(self, api_key: str, openclaw_memory_path: str):
        self.verbose = str(os.getenv('GENESIS_VERBOSE', '')).lower() in {"1", "true", "yes", "y"}
        self.agent = NanoGenesisWithPolyhedron(
            api_key=api_key,
            model="deepseek-chat",
            user_persona_path="./data/user_persona.json"
        )
        self.conv_manager = ConversationManager()
        self.session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # 加载 OpenClaw 记忆
        try:
            self.openclaw_loader = OpenClawMemoryLoader(openclaw_memory_path)
            self.openclaw_memories = self.openclaw_loader.load_all_memories()
            
            print("="*60)
            print("Genesis v0.2.0 + OpenClaw 记忆")
            print("="*60)
            print(f"会话 ID: {self.session_id}")
            print(f"OpenClaw 记忆: {len(self.openclaw_memories)} 个文件")
            print("\n命令:")
            print("  /help     - 显示帮助")
            print("  /memory   - 查看 OpenClaw 记忆统计")
            print("  /search   - 搜索记忆")
            print("  /history  - 查看对话历史")
            print("  /stats    - 查看统计信息")
            print("  /clear    - 清空对话")
            print("  /exit     - 退出")
            print("\n开始对话吧！Genesis 可以使用 OpenClaw 的所有记忆。\n")
        
        except Exception as e:
            print(f"加载 OpenClaw 记忆失败: {e}")
            print("将在无记忆模式下运行")
            self.openclaw_loader = None
            self.openclaw_memories = {}
    
    async def chat(self):
        """开始对话"""
        
        while True:
            try:
                user_input = input("你: ").strip()
                
                if not user_input:
                    continue
                
                # 处理命令
                if user_input.startswith('/'):
                    if await self._handle_command(user_input):
                        continue
                    else:
                        break
                
                # 添加用户消息
                self.conv_manager.add_message(self.session_id, "user", user_input)
                
                print("\nGenesis: [思考中，搜索相关记忆...]", end='\r')
                
                # 处理请求（带上 OpenClaw 记忆）
                result = await self.agent.process(
                    user_input=user_input,
                    intent_type="problem",
                    available_contexts=self.openclaw_memories
                )
                
                print(" " * 60, end='\r')
                
                # 显示响应
                response = result['response']
                print(f"Genesis: {response}\n")
                
                # 显示使用的记忆
                if self.verbose and result['selected_contexts']:
                    print(f"[使用了 {len(result['selected_contexts'])} 个 OpenClaw 记忆]")
                
                # 添加 AI 响应
                self.conv_manager.add_message(self.session_id, "assistant", response)
            
            except KeyboardInterrupt:
                print("\n\n再见！")
                break
            except Exception as e:
                print(f"\n错误: {e}\n")
    
    async def _handle_command(self, command: str) -> bool:
        """处理命令"""
        parts = command.split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""
        
        if cmd == '/exit' or cmd == '/quit':
            print("\n再见！")
            return False
        
        elif cmd == '/help':
            print("\n命令列表:")
            print("  /help           - 显示此帮助")
            print("  /memory         - 查看 OpenClaw 记忆统计")
            print("  /search <关键词> - 搜索 OpenClaw 记忆")
            print("  /history        - 查看对话历史")
            print("  /stats          - 查看统计信息")
            print("  /clear          - 清空当前对话")
            print("  /exit           - 退出程序\n")
        
        elif cmd == '/memory':
            if self.openclaw_loader:
                summary = self.openclaw_loader.get_summary()
                print("\nOpenClaw 记忆统计:")
                print("-" * 60)
                print(f"总文件数: {summary['total_files']}")
                print(f"总大小: {summary['total_size']:,} 字符")
                print(f"文件类型: {summary['by_extension']}")
                print(f"路径: {summary['memory_path']}")
                print("-" * 60 + "\n")
            else:
                print("\n未加载 OpenClaw 记忆\n")
        
        elif cmd == '/search':
            if not arg:
                print("\n用法: /search <关键词>\n")
            elif self.openclaw_loader:
                results = self.openclaw_loader.search_memories(arg, limit=10)
                print(f"\n搜索 '{arg}' 找到 {len(results)} 个结果:")
                print("-" * 60)
                for i, (key, content) in enumerate(results.items(), 1):
                    preview = content[:100].replace('\n', ' ')
                    print(f"{i}. {key}")
                    print(f"   {preview}...")
                print("-" * 60 + "\n")
            else:
                print("\n未加载 OpenClaw 记忆\n")
        
        elif cmd == '/history':
            messages = self.conv_manager.get_messages(self.session_id)
            print(f"\n对话历史 (共 {len(messages)} 条):")
            print("-" * 60)
            for msg in messages:
                role_name = "你" if msg.role == "user" else "Genesis"
                content = msg.content[:100] + "..." if len(msg.content) > 100 else msg.content
                print(f"[{role_name}] {content}")
            print("-" * 60 + "\n")
        
        elif cmd == '/stats':
            summary = self.conv_manager.get_summary(self.session_id)
            stats = self.agent.get_statistics()
            
            print("\n统计信息:")
            print("-" * 60)
            print(f"对话轮次: {summary['total_messages']}")
            print(f"用户消息: {summary['user_messages']}")
            print(f"AI 响应: {summary['assistant_messages']}")
            print(f"对话时长: {summary['duration']}")
            print(f"\n用户画像:")
            print(f"  交互次数: {stats['user_interactions']}")
            print(f"  置信度: {stats['user_confidence']:.2f}")
            print(f"  专业领域: {', '.join(stats['user_expertise']) if stats['user_expertise'] else '通用'}")
            
            if self.openclaw_loader:
                print(f"\nOpenClaw 记忆: {len(self.openclaw_memories)} 个文件")
            
            print("-" * 60 + "\n")
        
        elif cmd == '/clear':
            self.conv_manager.clear_conversation(self.session_id)
            self.session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            print(f"\n对话已清空，新会话 ID: {self.session_id}\n")
        
        else:
            print(f"\n未知命令: {command}")
            print("输入 /help 查看可用命令\n")
        
        return True


async def main():
    """主函数"""
    import os
    
    # 获取 API key
    api_key = os.getenv('DEEPSEEK_API_KEY')
    openclaw_path = None

    if len(sys.argv) > 2:
        api_key = sys.argv[1]
        openclaw_path = sys.argv[2]
    elif len(sys.argv) > 1:
        if not api_key:
            api_key = sys.argv[1]
        else:
            openclaw_path = sys.argv[1]

    if not api_key:
        print("请提供 API key:")
        print("  方式1: export DEEPSEEK_API_KEY='your-key'")
        print("  方式2: python3 chat_with_openclaw.py your-key [openclaw-path]")
        sys.exit(1)

    if not openclaw_path:
        # 尝试常见路径
        common_paths = [
            "./data/openclaw_memory",
            "~/.openclaw/memory",
            "~/openclaw/data",
            "~/.openclaw/data",
        ]
        
        for path in common_paths:
            expanded = Path(path).expanduser()
            if expanded.exists():
                openclaw_path = str(expanded)
                break
    
    if not openclaw_path:
        print("未找到 OpenClaw 记忆路径")
        print("请指定路径: python3 chat_with_openclaw.py api-key /path/to/openclaw/memory")
        sys.exit(1)
    
    # 创建对话
    chat = GenesisWithOpenClaw(api_key, openclaw_path)
    await chat.chat()


if __name__ == '__main__':
    asyncio.run(main())
