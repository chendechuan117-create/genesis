#!/usr/bin/env python3
"""
直接测试 - 绕过复杂流程
"""

import asyncio
import subprocess
import json
import os


async def test_api():
    """测试 API 调用"""
    print("测试 1: 直接调用 API")

    api_key = os.getenv('DEEPSEEK_API_KEY')
    if not api_key:
        raise RuntimeError("请先设置环境变量 DEEPSEEK_API_KEY")
    
    data = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": "你是一个助手"},
            {"role": "user", "content": "打开chrome浏览器"}
        ],
        "tools": [{
            "type": "function",
            "function": {
                "name": "shell",
                "description": "执行shell命令",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "command": {"type": "string"}
                    },
                    "required": ["command"]
                }
            }
        }],
        "max_tokens": 500
    }
    
    cmd = [
        'curl', '-s', '-X', 'POST',
        'https://api.deepseek.com/v1/chat/completions',
        '-H', f'Authorization: Bearer {api_key}',
        '-H', 'Content-Type: application/json',
        '-d', json.dumps(data)
    ]
    
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
    response = json.loads(result.stdout)
    
    print(f"✓ API 调用成功")
    print(f"  响应: {response['choices'][0]['message'].get('content', 'None')[:100]}")
    
    if 'tool_calls' in response['choices'][0]['message']:
        print(f"  工具调用: {response['choices'][0]['message']['tool_calls']}")
    
    return response


if __name__ == '__main__':
    asyncio.run(test_api())
